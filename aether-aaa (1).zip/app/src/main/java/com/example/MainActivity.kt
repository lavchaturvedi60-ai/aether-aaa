package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.DashboardTab
import com.example.ui.screens.PipelineTab
import com.example.ui.screens.StudioTab
import com.example.ui.screens.CoPilotTab
import com.example.ui.screens.ProjectsTab
import com.example.ui.screens.SettingsTab
import com.example.ui.theme.*
import com.example.ui.viewmodel.AgencyViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Setup high-performance Edge-To-Edge content drawing
        enableEdgeToEdge()
        
        setContent {
            MyApplicationTheme {
                val viewModel: AgencyViewModel by viewModels { AgencyViewModel.Factory }
                
                // Collect states from ViewModel flow reactively
                val clients by viewModel.clients.collectAsStateWithLifecycle()
                val workflows by viewModel.workflows.collectAsStateWithLifecycle()
                val logs by viewModel.logs.collectAsStateWithLifecycle()
                val projects by viewModel.projects.collectAsStateWithLifecycle()
                val tasks by viewModel.tasks.collectAsStateWithLifecycle()
                val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
                val coPilotResponse by viewModel.coPilotResponse.collectAsStateWithLifecycle()
                val isSimulating by viewModel.isSimulating.collectAsStateWithLifecycle()
                val logTheme by viewModel.logTheme.collectAsStateWithLifecycle()
                val adMode by viewModel.adMode.collectAsStateWithLifecycle()
                val customAgencyName by viewModel.customAgencyName.collectAsStateWithLifecycle()
                val maxLogLimit by viewModel.maxLogLimit.collectAsStateWithLifecycle()
                val currentPlan by viewModel.currentPlan.collectAsStateWithLifecycle()
                val isBillingYearly by viewModel.isBillingYearly.collectAsStateWithLifecycle()

                var currentTab by remember { mutableStateOf(0) } // 0: Workspace, 1: Clients, 2: Studio, 3: Projects, 4: Settings
                var showAssistantOverlay by remember { mutableStateOf(false) }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(ElegantBg),
                    floatingActionButton = {
                        if (!showAssistantOverlay) {
                            FloatingActionButton(
                                onClick = { showAssistantOverlay = true },
                                containerColor = PurpleAccentLight,
                                contentColor = PurpleAccentText,
                                shape = CircleShape,
                                modifier = Modifier
                                    .padding(bottom = if (adMode == "Free") 48.dp else 4.dp)
                                    .testTag("floating_ai_assistant_fab")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Face,
                                        contentDescription = "Consult Aether AI",
                                        modifier = Modifier.size(20.dp),
                                        tint = PurpleAccentText
                                    )
                                    Text("Consult AI", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PurpleAccentText)
                                }
                            }
                        }
                    },
                    bottomBar = {
                        Column {
                            if (adMode == "Free") {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF221133)) // Sleek dark deep space purple
                                        .border(1.dp, Color(0xFF4A2574))
                                        .clickable {
                                            currentTab = 4 // Navigate to Settings payment
                                            viewModel.resetCoPilotResponse()
                                        }
                                        .padding(vertical = 12.dp, horizontal = 16.dp)
                                        .testTag("sponsored_ad_banner")
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(WarningOrange)
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    "SPONSOR",
                                                    style = MaterialTheme.typography.labelSmall.copy(
                                                        color = Color.Black,
                                                        fontWeight = FontWeight.Black,
                                                        fontSize = 8.sp,
                                                        letterSpacing = 0.5.sp
                                                    )
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Text(
                                                "Compute nodes provided by external sponsors. Get full speed.",
                                                style = MaterialTheme.typography.labelSmall.copy(color = Color.White),
                                                maxLines = 1,
                                                fontSize = 11.sp
                                            )
                                        }
                                        Text(
                                            "Upgrade for $1",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = PurpleAccentLight,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        )
                                    }
                                }
                            }
                            NavigationBar(
                                containerColor = ElegantNavBg,
                                tonalElevation = 8.dp,
                                modifier = Modifier
                                    .testTag("bottom_nav_bar")
                                    .windowInsetsPadding(WindowInsets.navigationBars) // Safe bottom bar buffer
                            ) {
                                NavigationBarItem(
                                    selected = currentTab == 0,
                                    onClick = { 
                                        currentTab = 0 
                                        viewModel.resetCoPilotResponse()
                                    },
                                    label = { Text("Workspace", fontSize = 9.sp, maxLines = 1) },
                                    icon = { Icon(Icons.Default.Home, contentDescription = "Workspace") },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = ElegantBg,
                                        selectedTextColor = PurpleAccentLight,
                                        indicatorColor = PurpleAccentMuted,
                                        unselectedIconColor = ElegantSubtext,
                                        unselectedTextColor = ElegantSubtext
                                    )
                                )
                                NavigationBarItem(
                                    selected = currentTab == 1,
                                    onClick = { 
                                        currentTab = 1 
                                        viewModel.resetCoPilotResponse()
                                    },
                                    label = { Text("Clients", fontSize = 9.sp, maxLines = 1) },
                                    icon = { Icon(Icons.Default.Person, contentDescription = "Clients") },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = ElegantBg,
                                        selectedTextColor = PurpleAccentLight,
                                        indicatorColor = PurpleAccentMuted,
                                        unselectedIconColor = ElegantSubtext,
                                        unselectedTextColor = ElegantSubtext
                                    )
                                )
                                NavigationBarItem(
                                    selected = currentTab == 2,
                                    onClick = { 
                                        currentTab = 2 
                                        viewModel.resetCoPilotResponse()
                                    },
                                    label = { Text("Studio", fontSize = 9.sp, maxLines = 1) },
                                    icon = { Icon(Icons.Default.Build, contentDescription = "Studio") },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = ElegantBg,
                                        selectedTextColor = PurpleAccentLight,
                                        indicatorColor = PurpleAccentMuted,
                                        unselectedIconColor = ElegantSubtext,
                                        unselectedTextColor = ElegantSubtext
                                    )
                                )
                                NavigationBarItem(
                                    selected = currentTab == 3,
                                    onClick = { 
                                        currentTab = 3 
                                        viewModel.resetCoPilotResponse()
                                    },
                                    label = { Text("Projects", fontSize = 9.sp, maxLines = 1) },
                                    icon = { Icon(Icons.Default.List, contentDescription = "Projects") },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = ElegantBg,
                                        selectedTextColor = PurpleAccentLight,
                                        indicatorColor = PurpleAccentMuted,
                                        unselectedIconColor = ElegantSubtext,
                                        unselectedTextColor = ElegantSubtext
                                    )
                                )
                                NavigationBarItem(
                                    selected = currentTab == 4,
                                    onClick = { 
                                        currentTab = 4 
                                        viewModel.resetCoPilotResponse()
                                    },
                                    label = { Text("Settings", fontSize = 9.sp, maxLines = 1) },
                                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = ElegantBg,
                                        selectedTextColor = PurpleAccentLight,
                                        indicatorColor = PurpleAccentMuted,
                                        unselectedIconColor = ElegantSubtext,
                                        unselectedTextColor = ElegantSubtext
                                    )
                                )
                            }
                        }
                    },
                    contentWindowInsets = WindowInsets.safeDrawing // Prevent camera notch clipping
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(ElegantBg)
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            0 -> DashboardTab(
                                clients = clients,
                                workflows = workflows,
                                logs = logs,
                                onClearLogs = { viewModel.clearLogs() },
                                onTabSelect = { target -> 
                                    currentTab = target
                                    viewModel.resetCoPilotResponse()
                                },
                                agencyName = customAgencyName,
                                logTheme = logTheme
                            )
                            1 -> PipelineTab(
                                clients = clients,
                                isGenerating = isGenerating,
                                coPilotResponse = coPilotResponse,
                                onAddClient = { name, company, email, retainer, audit ->
                                    viewModel.addClient(name, company, email, retainer, audit)
                                },
                                onDeleteClient = { client ->
                                    viewModel.deleteClient(client)
                                },
                                onDiagnoseClient = { client ->
                                    viewModel.diagnoseClient(client)
                                },
                                onResetDiagnostic = {
                                    viewModel.resetCoPilotResponse()
                                }
                            )
                            2 -> StudioTab(
                                clients = clients,
                                workflows = workflows,
                                isGenerating = isGenerating,
                                coPilotResponse = coPilotResponse,
                                isSimulating = isSimulating,
                                onAddWorkflow = { clientId, clientName, name, desc, trigger, steps ->
                                    viewModel.addWorkflow(clientId, clientName, name, desc, trigger, steps)
                                },
                                onDeleteWorkflow = { workflow ->
                                    viewModel.deleteWorkflow(workflow)
                                },
                                onUpdateStatus = { workflow, status ->
                                    viewModel.updateWorkflowStatus(workflow, status)
                                },
                                onSimulateRun = { workflow ->
                                    viewModel.simulateWorkflowRun(workflow)
                                },
                                onGenWorkflowText = { desc, clientName ->
                                    viewModel.generateWorkflowFromText(desc, clientName)
                                },
                                onResetCopilot = {
                                    viewModel.resetCoPilotResponse()
                                },
                                onPostLog = { workflowId, workflowName, message, type ->
                                    viewModel.postLog(workflowId, workflowName, message, type)
                                }
                            )
                            3 -> ProjectsTab(
                                clients = clients,
                                projects = projects,
                                tasks = tasks,
                                onAddProject = { clientId, clientName, name, desc, deadline, status ->
                                    viewModel.addProject(clientId, clientName, name, desc, deadline, status)
                                },
                                onDeleteProject = { project ->
                                    viewModel.deleteProject(project)
                                },
                                onAddTask = { projectId, title, desc, assignee, deadline, stage ->
                                    viewModel.addTask(projectId, title, desc, assignee, deadline, stage)
                                },
                                onUpdateTaskStage = { task, stage ->
                                    viewModel.updateTaskStage(task, stage)
                                },
                                onDeleteTask = { task ->
                                    viewModel.deleteTask(task)
                                },
                                onPostLog = { workflowId, workflowName, message, type ->
                                    viewModel.postLog(workflowId, workflowName, message, type)
                                }
                            )
                            4 -> SettingsTab(
                                logTheme = logTheme,
                                onLogThemeChange = { viewModel.setLogTheme(it) },
                                adMode = adMode,
                                onAdModeChange = { viewModel.setAdMode(it) },
                                agencyName = customAgencyName,
                                onAgencyNameChange = { viewModel.setCustomAgencyName(it) },
                                maxLogLimit = maxLogLimit,
                                onMaxLogLimitChange = { viewModel.setMaxLogLimit(it) },
                                onClearLogs = { viewModel.clearLogs() },
                                currentPlan = currentPlan,
                                isBillingYearly = isBillingYearly,
                                onPlanChange = { plan, yearly ->
                                    viewModel.setSubscriptionPlan(plan, yearly)
                                },
                                cacheAnswers = viewModel.cacheAnswers.collectAsStateWithLifecycle().value,
                                onCacheAnswersChange = { viewModel.setCacheAnswers(it) },
                                aiCreativity = viewModel.aiCreativity.collectAsStateWithLifecycle().value,
                                onAiCreativityChange = { viewModel.setAiCreativity(it) },
                                geminiModel = viewModel.geminiModelSelected.collectAsStateWithLifecycle().value,
                                onGeminiModelChange = { viewModel.setGeminiModel(it) },
                                realtimeLogs = viewModel.realtimeLogsActive.collectAsStateWithLifecycle().value,
                                onRealtimeLogsChange = { viewModel.setRealtimeLogsActive(it) }
                            )
                        }

                        // Sliding Absolute Animated AI assistant Drawer Overlay
                        AnimatedVisibility(
                            visible = showAssistantOverlay,
                            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.7f))
                                    .clickable { showAssistantOverlay = false } // Scrim click triggers close
                            ) {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .fillMaxHeight(0.85f)
                                        .align(Alignment.BottomCenter)
                                        .clickable(enabled = false) {} // prevent clicking on items inside parent background
                                        .border(1.dp, ElegantBorder, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)),
                                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                                    colors = CardDefaults.cardColors(containerColor = ElegantBg)
                                ) {
                                    Column(modifier = Modifier.fillMaxSize()) {
                                        // Header of Drawer Panel
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(ElegantSurface)
                                                .padding(horizontal = 16.dp, vertical = 14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(32.dp)
                                                        .clip(CircleShape)
                                                        .background(Brush.linearGradient(colors = listOf(PurpleAccentHeavy, PurpleAccentLight)))
                                                ) {
                                                    Icon(
                                                        Icons.Default.Face,
                                                        contentDescription = null,
                                                        tint = Color.White,
                                                        modifier = Modifier.size(18.dp).align(Alignment.Center)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Column {
                                                    Text(
                                                        "Aether Cognitive Co-Pilot",
                                                        color = Color.White,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 13.sp
                                                    )
                                                    val subLabel = when (currentPlan) {
                                                        "Free" -> "STANDARD NODE BROADCAST"
                                                        "Silver" -> "SILVER DEPLOYMENT ACTIVE"
                                                        "Gold" -> "PRO COGNITIVE NETWORK ACCESS"
                                                        else -> "VIP TITAN UNLIMITED ROUTING"
                                                    }
                                                    Text(
                                                        text = subLabel,
                                                        color = if (currentPlan == "Free") ElegantSubtext else PurpleAccentLight,
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        letterSpacing = 1.sp
                                                    )
                                                }
                                            }
                                            IconButton(onClick = { showAssistantOverlay = false }) {
                                                Icon(Icons.Default.Close, contentDescription = "Close AI Drawer", tint = ElegantText)
                                            }
                                        }
                                        
                                        Divider(color = ElegantBorder)
                                        
                                        // View layout delegation
                                        CoPilotTab(
                                            isGenerating = isGenerating,
                                            coPilotResponse = coPilotResponse,
                                            onAskCoPilot = { question ->
                                                viewModel.askCoPilot(question)
                                            },
                                            onResetCopilot = {
                                                viewModel.resetCoPilotResponse()
                                            },
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
