package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.AgencyDao
import com.example.data.local.entity.AgentLog
import com.example.data.local.entity.AutomationWorkflow
import com.example.data.local.entity.Client
import com.example.data.local.entity.Project
import com.example.data.local.entity.Task

@Database(
    entities = [Client::class, AutomationWorkflow::class, AgentLog::class, Project::class, Task::class],
    version = 2,
    exportSchema = false
)
abstract class AgencyDatabase : RoomDatabase() {
    abstract fun agencyDao(): AgencyDao

    companion object {
        @Volatile
        private var INSTANCE: AgencyDatabase? = null

        fun getDatabase(context: Context): AgencyDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AgencyDatabase::class.java,
                    "agency_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
