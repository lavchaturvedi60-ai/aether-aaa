package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.AgentLog
import com.example.data.local.entity.AutomationWorkflow
import com.example.data.local.entity.Client
import com.example.data.local.entity.Project
import com.example.data.local.entity.Task
import kotlinx.coroutines.flow.Flow

@Dao
interface AgencyDao {
    // --- Clients ---
    @Query("SELECT * FROM clients ORDER BY createdAt DESC")
    fun getAllClients(): Flow<List<Client>>

    @Query("SELECT * FROM clients WHERE id = :id")
    suspend fun getClientById(id: Int): Client?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClient(client: Client)

    @Update
    suspend fun updateClient(client: Client)

    @Delete
    suspend fun deleteClient(client: Client)

    // --- Workflows ---
    @Query("SELECT * FROM workflows ORDER BY lastExecutedAt DESC")
    fun getAllWorkflows(): Flow<List<AutomationWorkflow>>

    @Query("SELECT * FROM workflows WHERE clientId = :clientId")
    fun getWorkflowsForClient(clientId: Int): Flow<List<AutomationWorkflow>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkflow(workflow: AutomationWorkflow)

    @Update
    suspend fun updateWorkflow(workflow: AutomationWorkflow)

    @Delete
    suspend fun deleteWorkflow(workflow: AutomationWorkflow)

    // --- Agent Logs ---
    @Query("SELECT * FROM agent_logs ORDER BY timestamp DESC LIMIT 200")
    fun getAllAgentLogs(): Flow<List<AgentLog>>

    @Query("SELECT * FROM agent_logs WHERE workflowId = :workflowId ORDER BY timestamp DESC")
    fun getLogsForWorkflow(workflowId: Int): Flow<List<AgentLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAgentLog(log: AgentLog)

    @Delete
    suspend fun deleteAgentLog(log: AgentLog)

    @Query("DELETE FROM agent_logs WHERE id IN (SELECT id FROM agent_logs ORDER BY timestamp ASC LIMIT :limit)")
    suspend fun trimOldestLogs(limit: Int)

    @Query("DELETE FROM agent_logs WHERE workflowId = :workflowId")
    suspend fun deleteLogsForWorkflow(workflowId: Int)

    @Query("DELETE FROM agent_logs")
    suspend fun clearAllLogs()

    // --- Projects ---
    @Query("SELECT * FROM projects ORDER BY createdAt DESC")
    fun getAllProjects(): Flow<List<Project>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: Project)

    @Update
    suspend fun updateProject(project: Project)

    @Delete
    suspend fun deleteProject(project: Project)

    // --- Tasks ---
    @Query("SELECT * FROM project_tasks ORDER BY createdAt DESC")
    fun getAllTasks(): Flow<List<Task>>

    @Query("SELECT * FROM project_tasks WHERE projectId = :projectId ORDER BY createdAt DESC")
    fun getTasksForProject(projectId: Int): Flow<List<Task>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: Task)

    @Update
    suspend fun updateTask(task: Task)

    @Delete
    suspend fun deleteTask(task: Task)
}
