package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "agent_logs")
data class AgentLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val workflowId: Int,
    val workflowName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val message: String,
    val type: String // "INFO", "SUCCESS", "WARNING", "ERROR"
)
