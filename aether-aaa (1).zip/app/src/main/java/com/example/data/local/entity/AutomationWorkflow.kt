package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "workflows")
data class AutomationWorkflow(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val clientId: Int,
    val clientName: String,
    val name: String,
    val description: String,
    val steps: String, // Comma-separated or serialized list of blocks
    val triggerType: String, // "Webhook", "Schedule", "Email Received", "Form Saved"
    val status: String, // "Draft", "Testing", "Active", "Paused"
    val apiCallsCount: Int,
    val successRate: Float,
    val lastExecutedAt: Long = System.currentTimeMillis()
)
