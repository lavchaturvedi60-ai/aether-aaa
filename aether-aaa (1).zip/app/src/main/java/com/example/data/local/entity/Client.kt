package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "clients")
data class Client(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val company: String,
    val email: String,
    val stage: String, // "Lead", "Discovery", "In Forge", "Deployed", "Optimizing"
    val monthlyRetainer: Double,
    val businessAudit: String,
    val createdAt: Long = System.currentTimeMillis()
)
