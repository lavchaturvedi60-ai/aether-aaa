package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class Project(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val clientId: Int,
    val clientName: String,
    val name: String,
    val description: String,
    val deadline: Long,
    val status: String, // "Not Started", "In Progress", "Completed"
    val createdAt: Long = System.currentTimeMillis()
)
