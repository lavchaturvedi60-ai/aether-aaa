package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "project_tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val projectId: Int,
    val title: String,
    val description: String,
    val assignee: String, // e.g. "Dev-Agent Alpha", "CRM Bot", "User", "Support Agent"
    val deadline: Long,
    val isCompleted: Boolean = false,
    val stage: String = "Todo", // "Todo", "In Forge", "Testing", "Completed"
    val createdAt: Long = System.currentTimeMillis()
)
