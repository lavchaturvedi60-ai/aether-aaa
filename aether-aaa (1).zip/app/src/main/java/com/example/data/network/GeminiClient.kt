package com.example.data.network

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiClient {
    private const val TAG = "GeminiClient"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    /**
     * Checks if the API key is configured and not the default placeholder.
     */
    fun isApiKeyConfigured(): Boolean {
        val key = BuildConfig.GEMINI_API_KEY
        return key.isNotEmpty() && key != "MY_GEMINI_API_KEY" && !key.contains("PLACEHOLDER")
    }

    /**
     * Calls Gemini-3.5-flash to get text recommendations, script formulations, or audits.
     */
    suspend fun generateContent(prompt: String, systemInstruction: String? = null): String = withContext(Dispatchers.IO) {
        if (!isApiKeyConfigured()) {
            Log.w(TAG, "API Key is not configured. Returning rich simulated intelligence.")
            return@withContext getMockResponse(prompt)
        }

        try {
            val root = JSONObject()
            
            // Contents
            val contentsArr = JSONArray()
            val contentObj = JSONObject()
            val partsArr = JSONArray()
            val partObj = JSONObject()
            partObj.put("text", prompt)
            partsArr.put(partObj)
            contentObj.put("parts", partsArr)
            contentsArr.put(contentObj)
            root.put("contents", contentsArr)

            // System Instructions
            if (systemInstruction != null) {
                val sysInstObj = JSONObject()
                val sysPartsArr = JSONArray()
                val sysPartObj = JSONObject()
                sysPartObj.put("text", systemInstruction)
                sysPartsArr.put(sysPartObj)
                sysInstObj.put("parts", sysPartsArr)
                root.put("systemInstruction", sysInstObj)
            }

            // Generation config
            val genConfig = JSONObject()
            genConfig.put("temperature", 0.7)
            root.put("generationConfig", genConfig)

            val jsonMediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = root.toString().toRequestBody(jsonMediaType)

            val url = "$BASE_URL?key=${BuildConfig.GEMINI_API_KEY}"
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val code = response.code
                    val body = response.body?.string() ?: ""
                    Log.e(TAG, "API calling failed: $code - $body")
                    return@withContext "Error: API Response code $code. Falling back to local offline generation."
                }

                val responseBodyStr = response.body?.string() ?: ""
                val responseJson = JSONObject(responseBodyStr)
                val candidates = responseJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val content = firstCandidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        return@withContext parts.getJSONObject(0).optString("text", "No text generated.")
                    }
                }
                return@withContext "Parsed successfully but did not detect a valid text block. Please retry."
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during Gemini dispatch", e)
            return@withContext "Integration Timeout / Network Exception: ${e.message}\nReturning co-pilot assistant mode."
        }
    }

    /**
     * Outstanding custom simulated fallbacks. Perfect for showcase when API Key is missing.
     */
    private fun getMockResponse(prompt: String): String {
        val uppercase = prompt.uppercase()
        return when {
            uppercase.contains("AUDIT") || uppercase.contains("DIAGNOST") -> {
                """
                # [Nexus Co-pilot Portal] - AI Operational Assessment (Offline Mode)
                
                Analyzing client business structure... We have detected multiple operational bottlenecks. 
                Below is a pre-negotiated high-performance Odoo-inspired AI automation blueprint:
                
                ## 📊 Pipeline Diagnostic Summary
                1. **Lead Response Friction**: Sales inquiries take average 12 hours to respond.
                2. **Data-Silo Overhead**: Manual copy-pasting required from Stripe to Airtable.
                3. **Content Bottleneck**: Generating customer summary notes takes 20 minutes per call.
                
                ## ⚡ Proposed Agency Solutions
                *   **Deploy AI Agent 1**: Automatic Lead Qualification using *Gemini-3.5-flash*. Extracts customer intent in real-time, categorizes CRM slots, and fires a webhook.
                *   **Deploy AI Agent 2**: Multi-platform Sync Stream. Automates client onboarding, triggers Slack alert hubs, and emails automated NDA agreements.
                
                *Note: Connect your Gemini API Key in the AI Studio Secrets panel to activate live customized intelligence models.*
                """.trimIndent()
            }
            uppercase.contains("WORKFLOW") || uppercase.contains("STUDIO") || uppercase.contains("GENERATE") -> {
                """
                # Custom Workflow Blueprint Generated Successfully
                Based on your automation parameters, here is the technical specification:
                
                ## 🔗 Multi-Step Integration Stack
                1. **[TRIGGER] Webhook (URL: /v1/incoming/leads)**
                   * Captures raw incoming prospect parameters (email, company, statement of work).
                2. **[AI ACTION] Deep Extraction Core (powered by Gemini)**
                   * Extracts budget size, urgency level, priority, and assigns category.
                3. **[DATABASE ACTION] Write to Local Room DB/CRM**
                   * Stores prospect metadata and registers contract potential.
                4. **[ALERT NODE] Slack Sync Channel**
                   * Automatically shoots card notifications to `#sales-aaa` with direct call hooks.
                   
                ## 💻 Executable Python Script Sample (Make.com compatible)
                ```python
                import json
                import requests

                def handle_webhook(lead_data):
                    # Step 1: Call Gemini Flash
                    headers = {"Content-Type": "application/json"}
                    payload = {
                        "contents": [{"parts": [{"text": f"Extract urgency from: {lead_data['description']}"}]}]
                    }
                    response = requests.post("https://generativelanguage.googleapis.com/...key=KEY", json=payload, headers=headers)
                    analysis = response.json()['candidates'][0]['content']['parts'][0]['text']
                    
                    # Step 2: Post back to Agent DB and shoot Slack Alert
                    slack_hook = "https://hooks.slack.com/services/T00/B00/X00"
                    requests.post(slack_hook, json={"text": f"🔥 New High Priority Lead Analyzed: {analysis}"})
                ```
                """.trimIndent()
            }
            else -> {
                """
                # Nexus Agency Co-Pilot Connected
                Welcome to your command hub. As your active AAA advisor, I can help you:
                * Build high-efficiency automation blueprints (include "generate workflow" in prompt)
                * Run client audits and pipeline diagnostics (include "audit client" in prompt)
                * Draft statement-of-work (SOW) documents and custom API scripts.
                
                **Tip**: To unlock our live generative models, enter your `GEMINI_API_KEY` into the AI Studio Secrets panel.
                """.trimIndent()
            }
        }
    }
}
