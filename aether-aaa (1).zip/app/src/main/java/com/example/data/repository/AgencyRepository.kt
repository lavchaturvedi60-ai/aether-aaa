package com.example.data.repository

import com.example.data.local.dao.AgencyDao
import com.example.data.local.entity.AgentLog
import com.example.data.local.entity.AutomationWorkflow
import com.example.data.local.entity.Client
import com.example.data.local.entity.Project
import com.example.data.local.entity.Task
import com.example.data.network.GeminiClient
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.util.UUID

class AgencyRepository(private val agencyDao: AgencyDao) {

    val allClients: Flow<List<Client>> = agencyDao.getAllClients()
    val allWorkflows: Flow<List<AutomationWorkflow>> = agencyDao.getAllWorkflows()
    val allLogs: Flow<List<AgentLog>> = agencyDao.getAllAgentLogs()
    val allProjects: Flow<List<Project>> = agencyDao.getAllProjects()
    val allTasks: Flow<List<Task>> = agencyDao.getAllTasks()

    suspend fun getClientById(id: Int): Client? = agencyDao.getClientById(id)

    suspend fun insertClient(client: Client) = agencyDao.insertClient(client)
    suspend fun updateClient(client: Client) = agencyDao.updateClient(client)
    suspend fun deleteClient(client: Client) = agencyDao.deleteClient(client)

    suspend fun insertWorkflow(workflow: AutomationWorkflow) = agencyDao.insertWorkflow(workflow)
    suspend fun updateWorkflow(workflow: AutomationWorkflow) = agencyDao.updateWorkflow(workflow)
    suspend fun deleteWorkflow(workflow: AutomationWorkflow) = agencyDao.deleteWorkflow(workflow)

    fun getWorkflowsForClient(clientId: Int): Flow<List<AutomationWorkflow>> = agencyDao.getWorkflowsForClient(clientId)
    fun getLogsForWorkflow(workflowId: Int): Flow<List<AgentLog>> = agencyDao.getLogsForWorkflow(workflowId)

    suspend fun insertAgentLog(log: AgentLog) = agencyDao.insertAgentLog(log)
    suspend fun deleteAgentLog(log: AgentLog) = agencyDao.deleteAgentLog(log)
    suspend fun trimOldestLogs(limit: Int) = agencyDao.trimOldestLogs(limit)
    suspend fun clearLogs() = agencyDao.clearAllLogs()

    // --- Projects & Tasks ---
    suspend fun insertProject(project: Project) = agencyDao.insertProject(project)
    suspend fun updateProject(project: Project) = agencyDao.updateProject(project)
    suspend fun deleteProject(project: Project) = agencyDao.deleteProject(project)

    suspend fun insertTask(task: Task) = agencyDao.insertTask(task)
    suspend fun updateTask(task: Task) = agencyDao.updateTask(task)
    suspend fun deleteTask(task: Task) = agencyDao.deleteTask(task)

    fun getTasksForProject(projectId: Int): Flow<List<Task>> = agencyDao.getTasksForProject(projectId)

    // --- Gemini Callers ---
    suspend fun callGemini(prompt: String, systemInstruction: String? = null): String {
        return GeminiClient.generateContent(prompt, systemInstruction)
    }

    /**
     * Seed the database if it has no data, giving a fantastic Odoo starting experience.
     */
    suspend fun seedDatabaseIfEmpty() {
        val existingClients = allClients.firstOrNull()
        if (existingClients.isNullOrEmpty()) {
            // Seed Clients
            val c1 = Client(
                name = "Sarah Jenkins",
                company = "Apex Global Logistics",
                email = "sjenkins@apexlogistics.com",
                stage = "Deployed",
                monthlyRetainer = 1800.0,
                businessAudit = "Takes 24 hours of manual labor to parse customs manifests and direct dispatch trucks. Bottlenecks: slow email ingestion, error-prone manual Excel data entry."
            )
            val c2 = Client(
                name = "Dr. Michael Chen",
                company = "Nova Care Clinics",
                email = "mchen@novacareclinics.org",
                stage = "In Forge",
                monthlyRetainer = 3500.0,
                businessAudit = "Inbound clinic leads requesting appointments fail to register in EHR. Bottlenecks: manual phone calls required, lack of integration with appointment slots."
            )
            val c3 = Client(
                name = "Marcus Vance",
                company = "Skyline Realty Group",
                email = "mvance@skylinerealty.com",
                stage = "Lead",
                monthlyRetainer = 950.0,
                businessAudit = "Receives 500+ web portal leads per day across 4 platforms. Leads go stale before realtors call. Bottleneck: no automatic categorization or instant SMS scheduling."
            )

            agencyDao.insertClient(c1)
            agencyDao.insertClient(c2)
            agencyDao.insertClient(c3)

            // Re-read clients to get auto IDs
            val clients = agencyDao.getAllClients().firstOrNull() ?: return
            val apexId = clients.find { it.company.contains("Apex") }?.id ?: 1
            val novaId = clients.find { it.company.contains("Nova") }?.id ?: 2
            val skylineId = clients.find { it.company.contains("Skyline") }?.id ?: 3

            // Seed Workflows
            val w1 = AutomationWorkflow(
                clientId = apexId,
                clientName = "Apex Global Logistics",
                name = "Apex Manifest AI Ingester",
                description = "Monitors cargo inbox, parses PDF manifests with Gemini, structures SKU weights, and triggers Dispatcher API.",
                steps = "Trigger:Email Influx,Action:PDF Document OCR Engine,Action:Gemini Flash Cargo Classifier,Action:Dispatcher API Connector,Action:Driver Slack Hub",
                triggerType = "Email Received",
                status = "Active",
                apiCallsCount = 3780,
                successRate = 0.992f
            )

            val w2 = AutomationWorkflow(
                clientId = novaId,
                clientName = "Nova Care Clinics",
                name = "Doctor Scheduler Sync Flow",
                description = "Bridges inbound medical voicemails to FHIR platform, schedules doctor calendar nodes dynamically with Gemini verification.",
                steps = "Trigger:API Webhook,Action:Voice-to-Text Transcription,Action:Gemini Medical Entity Parser,Action:Google Calendar EHR API,Action:SMS Patient Confirmation",
                triggerType = "Webhook",
                status = "Testing",
                apiCallsCount = 290,
                successRate = 0.915f
            )

            val w3 = AutomationWorkflow(
                clientId = skylineId,
                clientName = "Skyline Realty Group",
                name = "Instant Realtor Qualifier",
                description = "Classifies inbound properties, ranks prospect heat maps, and sends priority push SMS to local agents.",
                steps = "Trigger:Form Saved,Action:Prospect Budget Classifier,Action:SMS Twilio Dispatcher,Action:Zillow API Feeder",
                triggerType = "Form Saved",
                status = "Draft",
                apiCallsCount = 0,
                successRate = 1.000f
            )

            agencyDao.insertWorkflow(w1)
            agencyDao.insertWorkflow(w2)
            agencyDao.insertWorkflow(w3)

            // Seed Agent Logs
            val seedLogs = listOf(
                AgentLog(
                    workflowId = 1,
                    workflowName = "Apex Manifest AI Ingester",
                    message = "Success: Webhook processed manifest PDF. Dispatched driver card #D-48995 to Seattle Cargo terminal.",
                    type = "SUCCESS"
                ),
                AgentLog(
                    workflowId = 1,
                    workflowName = "Apex Manifest AI Ingester",
                    message = "Gemini Flash token consumption: 812 prompt, 381 completion. Speed: 420ms.",
                    type = "INFO"
                ),
                AgentLog(
                    workflowId = 2,
                    workflowName = "Doctor Scheduler Sync Flow",
                    message = "Warning: Voicemail transcript audio was static. High fallback parsing activated.",
                    type = "WARNING"
                ),
                AgentLog(
                    workflowId = 2,
                    workflowName = "Doctor Scheduler Sync Flow",
                    message = "Successfully mapped appointment for Dr. Michael Chen (EHR DB Slot #A294). Phone alert sent.",
                    type = "SUCCESS"
                ),
                AgentLog(
                    workflowId = 1,
                    workflowName = "Apex Manifest AI Ingester",
                    message = "Heartbeat ping: Active listener successfully monitoring secure dispatch webhook inbox.",
                    type = "INFO"
                )
            )

            for (log in seedLogs) {
                agencyDao.insertAgentLog(log)
            }

            // Seed Projects
            val p1 = Project(
                clientId = apexId,
                clientName = "Apex Global Logistics",
                name = "Apex Manifest Automation Ingestion Setup",
                description = "Complete integration of PDF manifests using LLM parsing, routing directly to dispatcher CRM queues.",
                deadline = System.currentTimeMillis() + 7 * 24 * 3600 * 1000L, // 7 days from now
                status = "In Progress"
            )
            val p2 = Project(
                clientId = novaId,
                clientName = "Nova Care Clinics",
                name = "Nova Care Appointment EHR Scheduler",
                description = "Bridges inbound clinic lead widgets, voicemails, and appointment EHR slot sync APIs.",
                deadline = System.currentTimeMillis() + 14 * 24 * 3600 * 1000L, // 14 days from now
                status = "In Progress"
            )
            agencyDao.insertProject(p1)
            agencyDao.insertProject(p2)

            val projects = agencyDao.getAllProjects().firstOrNull() ?: return
            val p1Id = projects.find { it.name.contains("Apex") }?.id ?: 1
            val p2Id = projects.find { it.name.contains("Nova") }?.id ?: 2

            // Seed Tasks for Projects
            val t1 = Task(
                projectId = p1Id,
                title = "Design PDF Parsing JSON Manifest Template",
                description = "Construct specific data model fields for cargo logs including weights, shipper address, and SKU IDs.",
                assignee = "Dev-Agent Alpha",
                deadline = System.currentTimeMillis() + 2 * 24 * 3600 * 1000L,
                isCompleted = true,
                stage = "Completed"
            )
            val t2 = Task(
                projectId = p1Id,
                title = "Configure Gemini API Validation Pipeline",
                description = "Wire the extractor node to Gemini Flash parser endpoints and assert JSON validation states.",
                assignee = "Arch AI Bot",
                deadline = System.currentTimeMillis() + 4 * 24 * 3600 * 1000L,
                isCompleted = false,
                stage = "Testing"
            )
            val t3 = Task(
                projectId = p1Id,
                title = "Instant Dispatcher Webhook Routing",
                description = "Build a fast-acting, high-speed API webhook to dispatch orders directly to driver mobile nodes.",
                assignee = "User / Partner Manager",
                deadline = System.currentTimeMillis() + 6 * 24 * 3600 * 1000L,
                isCompleted = false,
                stage = "In Forge"
            )

            val t4 = Task(
                projectId = p2Id,
                title = "HIPAA Voice-to-Text Transcription Bot",
                description = "Set up Twilio webhook node utilizing high-fidelity assembly AI or Whisper to capture clear appointment texts.",
                assignee = "Support AI Bot",
                deadline = System.currentTimeMillis() + 3 * 24 * 3600 * 1000L,
                isCompleted = false,
                stage = "Testing"
            )
            val t5 = Task(
                projectId = p2Id,
                title = "Google Calendar EHR API integration",
                description = "Link slots securely for appointment queues checking real-time availability nodes.",
                assignee = "Dev-Agent Alpha",
                deadline = System.currentTimeMillis() + 9 * 24 * 3600 * 1000L,
                isCompleted = false,
                stage = "In Forge"
            )
            val t6 = Task(
                projectId = p2Id,
                title = "Patient SMS confirmation trigger flows",
                description = "Implement final transactional text alert alerts to notify patients when bookings complete.",
                assignee = "User / Partner Manager",
                deadline = System.currentTimeMillis() + 12 * 24 * 3600 * 1000L,
                isCompleted = false,
                stage = "Todo"
            )

            agencyDao.insertTask(t1)
            agencyDao.insertTask(t2)
            agencyDao.insertTask(t3)
            agencyDao.insertTask(t4)
            agencyDao.insertTask(t5)
            agencyDao.insertTask(t6)
        }
    }
}
