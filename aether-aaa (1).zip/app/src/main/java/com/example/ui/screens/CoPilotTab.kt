package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CoPilotTab(
    isGenerating: Boolean,
    coPilotResponse: String?,
    onAskCoPilot: (String) -> Unit,
    onResetCopilot: () -> Unit,
    modifier: Modifier = Modifier
) {
    var queryText by remember { mutableStateFlowOf("") }
    
    val shortcutPrompts = listOf(
        "Draft Client SOW Contract Proposal",
        "Explain how Aether operates faster than Odoo ERP",
        "Generate Python Make.com Webhook trigger boilerplates",
        "Pitch ideas for high-ticket Real Estate Automations"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ElegantBg)
            .padding(16.dp)
    ) {
        // Chat Window Body
        Box(
            modifier = Modifier
                .weight(1.0f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(ElegantSurface)
                .border(2.dp, ElegantBorder, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            if (coPilotResponse == null) {
                // Intro screen
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(PurpleAccentHeavy, PurpleAccentLight)
                                )
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Face,
                            contentDescription = "Aether",
                            tint = Color.White,
                            modifier = Modifier
                                .size(36.dp)
                                .align(Alignment.Center)
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Aether OS Co-Pilot",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = ElegantText,
                            fontWeight = FontWeight.ExtraBold
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Your AI Automation Agency expert advisor. Generate copy, audit integrations, or construct scripts instantly.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = ElegantSubtext,
                            lineHeight = 16.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        "TAP QUICK ACTION PROMPT:",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = PurpleAccentLight,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        shortcutPrompts.forEach { prompt ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(1.dp, ElegantBorder, RoundedCornerShape(8.dp))
                                    .clickable(enabled = !isGenerating) {
                                        onAskCoPilot(prompt)
                                    }
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = prompt,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            } else {
                // Display Results Markdown
                Column(modifier = Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(PurpleAccentLight)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "CO-PILOT CONSULTATION PORTAL",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = PurpleAccentLight,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                        IconButton(onClick = onResetCopilot) {
                            Icon(Icons.Default.Refresh, contentDescription = "Clear Session", tint = ElegantSubtext)
                        }
                    }
                    Divider(color = ElegantBorder, modifier = Modifier.padding(vertical = 4.dp))
                    
                    LazyColumn(
                        modifier = Modifier.weight(1.0f).padding(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF131215))
                                    .border(1.dp, ElegantBorder, RoundedCornerShape(8.dp))
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = coPilotResponse,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = ElegantText,
                                        lineHeight = 22.sp,
                                        fontFamily = if (coPilotResponse.contains("class") || coPilotResponse.contains("def ")) FontFamily.Monospace else FontFamily.Default
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Input text bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = queryText,
                onValueChange = { queryText = it },
                modifier = Modifier
                    .weight(1.0f)
                    .testTag("copilot_chat_input"),
                placeholder = { Text("Consult with Aether OS...", color = ElegantSubtext, fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = ElegantText,
                    unfocusedTextColor = ElegantText,
                    unfocusedBorderColor = ElegantBorder,
                    focusedBorderColor = PurpleAccentLight,
                    cursorColor = PurpleAccentLight
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (queryText.isNotEmpty() && !isGenerating) {
                        onAskCoPilot(queryText)
                        queryText = ""
                    }
                }),
                singleLine = true
            )

            Button(
                onClick = {
                    if (queryText.isNotEmpty()) {
                        onAskCoPilot(queryText)
                        queryText = ""
                    }
                },
                enabled = !isGenerating && queryText.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = PurpleAccentLight,
                    contentColor = PurpleAccentText,
                    disabledContainerColor = PurpleAccentLight.copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .size(54.dp)
                    .testTag("copilot_send_button"),
                contentPadding = PaddingValues(0.dp)
            ) {
                if (isGenerating) {
                    CircularProgressIndicator(color = PurpleAccentText, modifier = Modifier.size(20.dp))
                } else {
                    Icon(Icons.Default.Send, contentDescription = "Send prompt", tint = PurpleAccentText, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}
