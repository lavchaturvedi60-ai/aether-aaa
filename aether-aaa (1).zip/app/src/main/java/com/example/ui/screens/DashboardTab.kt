package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.AgentLog
import com.example.data.local.entity.Client
import com.example.data.local.entity.AutomationWorkflow
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardTab(
    clients: List<Client>,
    workflows: List<AutomationWorkflow>,
    logs: List<AgentLog>,
    onClearLogs: () -> Unit,
    onTabSelect: (Int) -> Unit,
    agencyName: String = "Nexus AI Agency",
    logTheme: String = "Obsidian",
    modifier: Modifier = Modifier
) {
    val totalRetainer = clients.sumOf { it.monthlyRetainer }
    val activeFlowsCount = workflows.count { it.status == "Active" }
    
    // Average success rate
    val avgSuccessRate = if (workflows.isNotEmpty()) {
        workflows.map { it.successRate }.average() * 100
    } else 0.0

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- Agency Header banner ---
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(PurpleAccentHeavy, PurpleAccentMuted)
                        )
                    )
                    .padding(20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "COMMAND CENTER",
                            style = MaterialTheme.typography.labelMedium.copy(
                                letterSpacing = 2.sp,
                                color = PurpleAccentLight,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(30.dp))
                                .background(Color.White.copy(alpha = 0.15f))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(SuccessGreen)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "LIVE FEED",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = agencyName,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "High-Performance ERP designed for rapid cognitive task orchestration.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    )
                }
            }
        }

        // --- Core Metrics Row ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricWidget(
                    title = "Monthly Retainer",
                    value = "$${String.format(Locale.getDefault(), "%,.0f", totalRetainer)}",
                    icon = Icons.Default.Add, // Standard representation of addition/value
                    color = SuccessGreen,
                    modifier = Modifier.weight(1f)
                )

                MetricWidget(
                    title = "Active Agents",
                    value = "$activeFlowsCount/${workflows.size}",
                    icon = Icons.Default.Refresh,
                    color = PurpleAccentLight,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricWidget(
                    title = "Avg Success Rate",
                    value = "${String.format(Locale.getDefault(), "%.1f", avgSuccessRate)}%",
                    icon = Icons.Default.Check,
                    color = PurpleAccentLight,
                    modifier = Modifier.weight(1f)
                )

                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(84.dp)
                        .border(1.dp, ElegantBorder, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = ElegantSurface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "Odoo Speed factor",
                            style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "10.4x",
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    color = PurpleAccentLight
                                )
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Fewer Nodes",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = SuccessGreen,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }
            }
        }

        // --- Live Agency Operations Terminal ---
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.List,
                        contentDescription = "Terminal",
                        tint = PurpleAccentLight
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "INTELLIGENT RUN TERMINAL",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = ElegantText,
                            letterSpacing = 1.sp
                        )
                    )
                }
                TextButton(
                    onClick = onClearLogs,
                    colors = ButtonDefaults.textButtonColors(contentColor = ElegantSubtext)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Clear logs", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Clear logs", style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        if (logs.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(ElegantSurface)
                        .border(1.dp, ElegantBorder, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Icon(Icons.Default.Info, contentDescription = "No events", tint = ElegantSubtext, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Terminal Quiet. No agent cycles triggered yet.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = ElegantSubtext)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        TextButton(onClick = { onTabSelect(2) }) {
                            Text("Go to Studio & Run Test Automation", style = MaterialTheme.typography.labelMedium.copy(color = PurpleAccentLight))
                        }
                    }
                }
            }
        } else {
            items(logs, key = { it.id }) { log ->
                TerminalLogItem(log, theme = logTheme)
            }
        }
    }
}

@Composable
fun MetricWidget(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(84.dp)
            .border(1.dp, ElegantBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = ElegantSurface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                title,
                style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.headlineSmall.copy(
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun TerminalLogItem(log: AgentLog, theme: String = "Obsidian") {
    val date = Date(log.timestamp)
    val formatter = remember { SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()) }
    val timeLabel = formatter.format(date)
    
    // Theme color mappings
    val containerBgColor = when (theme) {
        "Amber" -> Color(0xFF000000)
        "Matrix" -> Color(0xFF000000)
        "Cyberpunk" -> Color(0xFF0B0914)
        else -> Color(0xFF131215) // Obsidian
    }

    val terminalTextColor = when (theme) {
        "Amber" -> Color(0xFFFFB300)
        "Matrix" -> Color(0xFF00E676)
        "Cyberpunk" -> Color(0xFF00E5FF)
        else -> if (log.type == "ERROR") ErrorRed else ElegantText // Obsidian default
    }

    val prefixTextColor = when (theme) {
        "Amber" -> Color(0xFFFF8F00)
        "Matrix" -> Color(0xFF00CC44)
        "Cyberpunk" -> Color(0xFFFF007F) // neon hot pink
        else -> PurpleAccentLight // Obsidian
    }

    val terminalTimeColor = when (theme) {
        "Amber" -> Color(0xFFFFB300).copy(alpha = 0.6f)
        "Matrix" -> Color(0xFF00E676).copy(alpha = 0.6f)
        "Cyberpunk" -> Color(0xFF00E5FF).copy(alpha = 0.6f)
        else -> ElegantSubtext // Obsidian
    }

    val badgeColor = when (log.type) {
        "SUCCESS" -> SuccessGreen
        "ERROR" -> ErrorRed
        "WARNING" -> WarningOrange
        else -> if (theme == "Amber" || theme == "Matrix") Color.White else PurpleAccentLight
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(containerBgColor)
            .border(1.dp, if (theme == "Obsidian") ElegantBorder else ElegantBorder.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column(modifier = Modifier.width(82.dp)) {
                Text(
                    text = timeLabel,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        color = terminalTimeColor,
                        fontSize = 11.sp
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(badgeColor.copy(alpha = 0.15f))
                        .border(1.dp, badgeColor.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = log.type,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = badgeColor,
                            fontSize = 9.sp
                        ),
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "[${log.workflowName}]",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = prefixTextColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = log.message,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        color = terminalTextColor,
                        lineHeight = 16.sp
                    )
                )
            }
        }
    }
}
