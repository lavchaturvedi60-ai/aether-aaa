package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.Client
import com.example.ui.theme.*
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PipelineTab(
    clients: List<Client>,
    isGenerating: Boolean,
    coPilotResponse: String?,
    onAddClient: (String, String, String, Double, String) -> Unit,
    onDeleteClient: (Client) -> Unit,
    onDiagnoseClient: (Client) -> Unit,
    onResetDiagnostic: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateFlowOf(false) }
    var selectedClientForView by remember { mutableStateFlowOf<Client?>(null) }
    
    Box(modifier = modifier.fillMaxSize().background(ElegantBg)) {
        if (selectedClientForView != null) {
            // Detailed Client Slide-Up panel / Viewport
            ClientDetailView(
                client = selectedClientForView!!,
                isGenerating = isGenerating,
                coPilotResponse = coPilotResponse,
                onBack = { 
                    selectedClientForView = null 
                    onResetDiagnostic()
                },
                onDiagnose = { onDiagnoseClient(selectedClientForView!!) },
                onDelete = {
                    onDeleteClient(selectedClientForView!!)
                    selectedClientForView = null
                    onResetDiagnostic()
                }
            )
        } else {
            // CRM Pipelines Home
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "CLIENT PORTALS",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = ElegantText,
                                    letterSpacing = 1.sp
                                )
                            )
                            Text(
                                "Stage pipelines and billing metrics.",
                                style = MaterialTheme.typography.bodySmall.copy(color = ElegantSubtext)
                            )
                        }
                        
                        Button(
                            onClick = { showAddDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PurpleAccentLight,
                                contentColor = PurpleAccentText
                            ),
                            modifier = Modifier.testTag("add_client_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add Client", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New Client", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }

                if (clients.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(ElegantSurface)
                                .border(1.dp, ElegantBorder, RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(24.dp)
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = ElegantSubtext, modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    "No Agency Clients Found.",
                                    style = MaterialTheme.typography.titleSmall.copy(color = ElegantText)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    "Click 'New Client' at the top-right to register a prospect and diagnose their workflow bottlenecks with Gemini.",
                                    style = MaterialTheme.typography.bodySmall.copy(color = ElegantSubtext, lineHeight = 16.sp)
                                )
                            }
                        }
                    }
                } else {
                    items(clients, key = { it.id }) { client ->
                        ClientPipelineCard(
                            client = client,
                            onClick = { selectedClientForView = client }
                        )
                    }
                }
            }
        }

        // --- Dialog to Add Client ---
        if (showAddDialog) {
            AddClientDialog(
                onDismiss = { showAddDialog = false },
                onSave = { name, company, email, retainer, audit ->
                    onAddClient(name, company, email, retainer, audit)
                    showAddDialog = false
                }
            )
        }
    }
}

@Composable
fun ClientPipelineCard(client: Client, onClick: () -> Unit) {
    val stageColor = when (client.stage) {
        "Deployed" -> SuccessGreen
        "In Forge" -> PurpleAccentLight
        "Discovery" -> WarningOrange
        "Optimizing" -> PurpleAccentMuted
        else -> ElegantSubtext
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .border(1.dp, ElegantBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = ElegantSurface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1.0f)) {
                    Text(
                        text = client.company,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Contact: ${client.name} | ${client.email}",
                        style = MaterialTheme.typography.bodySmall.copy(color = ElegantSubtext),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(30.dp))
                        .background(stageColor.copy(alpha = 0.15f))
                        .border(1.dp, stageColor.copy(alpha = 0.4f), RoundedCornerShape(30.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = client.stage,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = stageColor
                        )
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = ElegantBorder)
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "Monthly Retainer",
                        style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext)
                    )
                    Text(
                        "$${String.format(Locale.getDefault(), "%,.0f", client.monthlyRetainer)} /mo",
                        style = MaterialTheme.typography.titleSmall.copy(
                            color = SuccessGreen,
                            fontWeight = FontWeight.ExtraBold
                        )
                    )
                }
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Diagnose bottlenecks",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = PurpleAccentLight,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Details",
                        tint = PurpleAccentLight,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ClientDetailView(
    client: Client,
    isGenerating: Boolean,
    coPilotResponse: String?,
    onBack: () -> Unit,
    onDiagnose: () -> Unit,
    onDelete: () -> Unit
) {
    var confirmDelete by remember { mutableStateFlowOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ElegantBg)
            .padding(16.dp)
    ) {
        // Top navbar back button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = ElegantText)
            }
            Text(
                text = "${client.company} cockpit",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = ElegantText
                )
            )
            IconButton(onClick = { confirmDelete = true }) {
                Icon(Icons.Default.Delete, contentDescription = "Delete client", tint = ErrorRed)
            }
        }

        Divider(color = ElegantBorder, modifier = Modifier.padding(vertical = 8.dp))

        LazyColumn(
            modifier = Modifier.weight(1.0f),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Client card review
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, ElegantBorder, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = ElegantSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("CONTRACT PORTAL", style = MaterialTheme.typography.labelSmall.copy(color = PurpleAccentLight, fontWeight = FontWeight.Bold))
                            Text("ID: #${client.id}", style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext))
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        
                        InfoRow(label = "Company Name", valStr = client.company)
                        InfoRow(label = "Representative", valStr = client.name)
                        InfoRow(label = "Email Endpoint", valStr = client.email)
                        InfoRow(label = "Monthly Fuel", valStr = "$${String.format(Locale.getDefault(), "%,.0f", client.monthlyRetainer)} per month")
                        InfoRow(label = "Current Stage", valStr = client.stage)
                    }
                }
            }

            // Reported physical bottleneck
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, ElegantBorder, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = ElegantSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = WarningOrange, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "OPERATIONAL ACCIDENT / BOTTLENECK",
                                style = MaterialTheme.typography.labelSmall.copy(color = WarningOrange, fontWeight = FontWeight.Bold)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = client.businessAudit,
                            style = MaterialTheme.typography.bodyMedium.copy(color = ElegantText, lineHeight = 20.sp)
                        )
                    }
                }
            }

            // AI Auditor Control Button
            item {
                Button(
                    onClick = onDiagnose,
                    enabled = !isGenerating,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PurpleAccentHeavy,
                        contentColor = Color.White,
                        disabledContainerColor = PurpleAccentHeavy.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                    } else {
                        Icon(Icons.Default.Face, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Initiate Co-pilot Diagnostic Audit", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Copilot generated diagnosis
            if (coPilotResponse != null) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, PurpleAccentLight.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF131215))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Face, contentDescription = null, tint = PurpleAccentLight, modifier = Modifier.size(22.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        "AETHER DIAGNOSTIC SOLUTION",
                                        style = MaterialTheme.typography.titleSmall.copy(color = PurpleAccentLight, fontWeight = FontWeight.Black)
                                        )
                                }
                                Text(
                                    "Powered by Flash",
                                    style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext)
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Divider(color = ElegantBorder)
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            // Visual prompt blocks
                            Text(
                                text = coPilotResponse,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = ElegantText,
                                    lineHeight = 22.sp
                                )
                            )
                        }
                    }
                }
            }
        }

        if (confirmDelete) {
            AlertDialog(
                onDismissRequest = { confirmDelete = false },
                title = { Text("Delete client portal?", color = ElegantText) },
                text = { Text("This removes ${client.company} and all matching automation workflows permanently.", color = ElegantSubtext) },
                confirmButton = {
                    TextButton(onClick = onDelete) {
                        Text("Delete", color = ErrorRed)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { confirmDelete = false }) {
                        Text("Cancel", color = ElegantText)
                    }
                },
                containerColor = ElegantSurface
            )
        }
    }
}

@Composable
fun InfoRow(label: String, valStr: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall.copy(color = ElegantSubtext))
        Text(text = valStr, style = MaterialTheme.typography.bodyMedium.copy(color = ElegantText, fontWeight = FontWeight.Bold))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddClientDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, String, Double, String) -> Unit
) {
    var name by remember { mutableStateFlowOf("") }
    var company by remember { mutableStateFlowOf("") }
    var email by remember { mutableStateFlowOf("") }
    var retainerStr by remember { mutableStateFlowOf("") }
    var auditStr by remember { mutableStateFlowOf("") }
    
    var errorMsg by remember { mutableStateFlowOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ONBOARD NEW AAA CLIENT", color = ElegantText, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = company,
                    onValueChange = { company = it },
                    label = { Text("Company Name") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ElegantText,
                        unfocusedTextColor = ElegantText,
                        unfocusedBorderColor = ElegantBorder,
                        focusedBorderColor = PurpleAccentLight,
                        cursorColor = PurpleAccentLight
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("company_input")
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Primary Representative Name") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ElegantText,
                        unfocusedTextColor = ElegantText,
                        unfocusedBorderColor = ElegantBorder,
                        focusedBorderColor = PurpleAccentLight,
                        cursorColor = PurpleAccentLight
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("name_input")
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Business Contact Email") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ElegantText,
                        unfocusedTextColor = ElegantText,
                        unfocusedBorderColor = ElegantBorder,
                        focusedBorderColor = PurpleAccentLight,
                        cursorColor = PurpleAccentLight
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("email_input")
                )

                OutlinedTextField(
                    value = retainerStr,
                    onValueChange = { retainerStr = it },
                    label = { Text("Monthly Contract Retainer ($)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ElegantText,
                        unfocusedTextColor = ElegantText,
                        unfocusedBorderColor = ElegantBorder,
                        focusedBorderColor = PurpleAccentLight,
                        cursorColor = PurpleAccentLight
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("retainer_input")
                )

                OutlinedTextField(
                    value = auditStr,
                    onValueChange = { auditStr = it },
                    label = { Text("Describe Process Bottleneck") },
                    maxLines = 4,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ElegantText,
                        unfocusedTextColor = ElegantText,
                        unfocusedBorderColor = ElegantBorder,
                        focusedBorderColor = PurpleAccentLight,
                        cursorColor = PurpleAccentLight
                    ),
                    placeholder = { Text("E.g. Manually copy incoming invoice data from emails to Odoo spreadsheet and scheduling calendars.", color = ElegantSubtext, fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth().height(100.dp).testTag("bottleneck_input")
                )

                if (errorMsg != null) {
                    Text(text = errorMsg!!, color = ErrorRed, style = MaterialTheme.typography.labelSmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val retainerVal = retainerStr.toDoubleOrNull()
                    if (company.isEmpty() || name.isEmpty() || email.isEmpty() || auditStr.isEmpty()) {
                        errorMsg = "Please populate all fields."
                    } else if (retainerVal == null || retainerVal <= 0) {
                        errorMsg = "Please insert valid positive retainer."
                    } else {
                        onSave(name, company, email, retainerVal, auditStr)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PurpleAccentLight, contentColor = PurpleAccentText),
                modifier = Modifier.testTag("submit_client_button")
            ) {
                Text("Onboard Client", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = ElegantText)
            }
        },
        containerColor = ElegantSurface
    )
}

// Wrapper for simple mutableStateOf declaration compatibility
fun <T> mutableStateFlowOf(value: T): MutableState<T> = mutableStateOf(value)
