package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.Client
import com.example.data.local.entity.Project
import com.example.data.local.entity.Task
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectsTab(
    clients: List<Client>,
    projects: List<Project>,
    tasks: List<Task>,
    onAddProject: (Int, String, String, String, Long, String) -> Unit,
    onDeleteProject: (Project) -> Unit,
    onAddTask: (Int, String, String, String, Long, String) -> Unit,
    onUpdateTaskStage: (Task, String) -> Unit,
    onDeleteTask: (Task) -> Unit,
    onPostLog: (Int, String, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeProjectId by remember { mutableStateOf<Int?>(null) }
    var showAddProjectDialog by remember { mutableStateOf(false) }
    var showAddTaskDialog by remember { mutableStateOf(false) }
    
    // Fallback selection of active project
    val activeProject = if (activeProjectId != null) {
        projects.find { it.id == activeProjectId } ?: projects.firstOrNull()
    } else {
        projects.firstOrNull()
    }
    
    // Update state to lock on active project ID
    LaunchedEffect(projects) {
        if (activeProjectId == null && projects.isNotEmpty()) {
            activeProjectId = projects.firstOrNull()?.id
        }
    }

    val projectTasks = if (activeProject != null) {
        tasks.filter { it.projectId == activeProject.id }
    } else {
        emptyList()
    }

    // Task columns configurations
    val stages = listOf("Todo", "In Forge", "Testing", "Completed")

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // --- Header ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    "PROJECT LIFE CYCLES",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = ElegantText,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    "Assign cognitive agents & trace milestones.",
                    style = MaterialTheme.typography.bodySmall.copy(color = ElegantSubtext)
                )
            }
            
            Button(
                onClick = { showAddProjectDialog = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = PurpleAccentLight,
                    contentColor = PurpleAccentHeavy
                ),
                modifier = Modifier.testTag("create_project_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add project")
                Spacer(modifier = Modifier.width(4.dp))
                Text("New Project", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- Horizontal Project Chips Selector ---
        if (projects.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(ElegantSurface)
                    .border(1.dp, ElegantBorder, RoundedCornerShape(12.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = ElegantSubtext, modifier = Modifier.size(36.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "No projects active. Click 'New Project' above to initiate.",
                        style = MaterialTheme.typography.bodySmall.copy(color = ElegantSubtext),
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(projects, key = { it.id }) { proj ->
                    val isSelected = activeProject?.id == proj.id
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) PurpleAccentHeavy else ElegantSurface)
                            .border(1.dp, if (isSelected) PurpleAccentLight else ElegantBorder, RoundedCornerShape(12.dp))
                            .clickable { activeProjectId = proj.id }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Column {
                            Text(
                                text = proj.name,
                                color = if (isSelected) Color.White else ElegantText,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Client: ${proj.clientName}",
                                color = if (isSelected) PurpleAccentLight else ElegantSubtext,
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Active Project Card Details & Stats
            if (activeProject != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ElegantBorder, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = ElegantSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.0f)) {
                                Text(
                                    text = activeProject.name,
                                    style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Client Workspace: ${activeProject.clientName}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = PurpleAccentLight)
                                )
                            }
                            
                            IconButton(
                                onClick = { 
                                    onDeleteProject(activeProject)
                                    onPostLog(0, activeProject.name, "Deleted project blueprint: ${activeProject.name}", "WARNING")
                                    activeProjectId = null
                                }
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete project", tint = ErrorRed.copy(alpha = 0.8f))
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = activeProject.description,
                            style = MaterialTheme.typography.bodySmall.copy(color = ElegantSubtext, lineHeight = 16.sp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // Progress and Deadline indicators
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val doneTasks = projectTasks.count { it.stage == "Completed" }
                            val totalTasks = projectTasks.size
                            val progressPercent = if (totalTasks > 0) (doneTasks.toFloat() / totalTasks) else 0f
                            
                            val df = remember { SimpleDateFormat("MMM d, yyyy", Locale.getDefault()) }
                            val deadlineStr = df.format(Date(activeProject.deadline))

                            Column {
                                Text(
                                    text = "METRIC CAPABILITY: ${doneTasks}/${totalTasks} TASKS ALIGNED",
                                    style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext, fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                LinearProgressIndicator(
                                    progress = progressPercent,
                                    color = SuccessGreen,
                                    trackColor = ElegantBorder,
                                    modifier = Modifier
                                        .width(200.dp)
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp))
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "DEADLINE GOAL",
                                    style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext, fontSize = 9.sp)
                                )
                                Text(
                                    text = deadlineStr,
                                    style = MaterialTheme.typography.titleSmall.copy(color = WarningOrange, fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Kanban Tasks list header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Interactive Kanban Board Node-Flow",
                        style = MaterialTheme.typography.titleSmall.copy(color = ElegantSubtext, fontWeight = FontWeight.Bold)
                    )
                    
                    TextButton(
                        onClick = { showAddTaskDialog = true },
                        colors = ButtonDefaults.textButtonColors(contentColor = PurpleAccentLight)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Task Block", style = MaterialTheme.typography.labelSmall)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // --- Kanban Board columns ---
                // We show an interactive Column slider or clean LazyColumn with sub-sections for screens.
                // To display it elegantly on mobile screens, we can render the columns vertically, 
                // allowing users to expand/collapse each Kanban column or swipe, or show interactive lists.
                // A very beautiful, Material 3 presentation is a vertical list of the columns, 
                // each containing their respective interactive tasks, showing exact task flow state change!
                LazyColumn(
                    modifier = Modifier.weight(1.0f),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(stages) { stage ->
                        val tasksInStage = projectTasks.filter { it.stage == stage }
                        val colColor = when(stage) {
                            "Todo" -> ElegantBorder
                            "In Forge" -> PurpleAccentLight
                            "Testing" -> WarningOrange
                            "Completed" -> SuccessGreen
                            else -> ElegantBorder
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF131215))
                                .border(1.dp, ElegantBorder, RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            // Column Title Bar
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(colColor)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = stage.uppercase() + " (${tasksInStage.size})",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = colColor,
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 1.sp
                                        )
                                    )
                                }

                                if (tasksInStage.isEmpty()) {
                                    Text("Empty Column", style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext, fontSize = 9.sp))
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            if (tasksInStage.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 12.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(ElegantSurface.copy(alpha = 0.5f))
                                        .border(1.dp, ElegantBorder.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                        .padding(12.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "No tasks currently in this pipeline stage.",
                                        style = MaterialTheme.typography.bodySmall.copy(color = ElegantSubtext, fontSize = 11.sp)
                                    )
                                }
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    tasksInStage.forEach { task ->
                                        KanbanTaskCard(
                                            task = task,
                                            stages = stages,
                                            onMoveStage = { newTask, nextStage ->
                                                onUpdateTaskStage(newTask, nextStage)
                                                onPostLog(
                                                    0, 
                                                    activeProject.name, 
                                                    "Task '${task.title}' moved to stage: $nextStage", 
                                                    if (nextStage == "Completed") "SUCCESS" else "INFO"
                                                )
                                            },
                                            onDelete = {
                                                onDeleteTask(task)
                                                onPostLog(0, activeProject.name, "Deleted task block: ${task.title}", "WARNING")
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // New Project Dialog
    if (showAddProjectDialog) {
        AddProjectDialog(
            clients = clients,
            onDismiss = { showAddProjectDialog = false },
            onSave = { clientId, clientName, name, desc, daysOffset ->
                val deadlineTime = System.currentTimeMillis() + daysOffset * 24 * 3600 * 1000L
                onAddProject(clientId, clientName, name, desc, deadlineTime, "In Progress")
                onPostLog(0, name, "Initialized new Project Framework: $name for client $clientName", "SUCCESS")
                showAddProjectDialog = false
            }
        )
    }

    // New Task Dialog
    if (showAddTaskDialog && activeProject != null) {
        AddTaskDialog(
            projectId = activeProject.id,
            onDismiss = { showAddTaskDialog = false },
            onSave = { title, desc, assignee, daysOffset, stage ->
                val deadlineTime = System.currentTimeMillis() + daysOffset * 24 * 3600 * 1000L
                onAddTask(activeProject.id, title, desc, assignee, deadlineTime, stage)
                onPostLog(0, activeProject.name, "Created task '$title' assigned to: $assignee", "INFO")
                showAddTaskDialog = false
            }
        )
    }
}

@Composable
fun KanbanTaskCard(
    task: Task,
    stages: List<String>,
    onMoveStage: (Task, String) -> Unit,
    onDelete: () -> Unit
) {
    val df = remember { SimpleDateFormat("MMM d", Locale.getDefault()) }
    val deadlineLabel = df.format(Date(task.deadline))
    
    val daysRemaining = ((task.deadline - System.currentTimeMillis()) / (24 * 3600 * 1000L)).toInt()
    val isOverdue = daysRemaining < 0 && task.stage != "Completed"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, ElegantBorder, RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = ElegantSurface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Text(
                    text = task.title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1.0f)
                )
                
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete task", tint = ElegantSubtext, modifier = Modifier.size(14.dp))
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = task.description,
                style = MaterialTheme.typography.bodySmall.copy(color = ElegantSubtext, lineHeight = 14.sp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Assignee & Deadline row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Assignee Badge
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(PurpleAccentHeavy)
                    ) {
                        val isAiBot = task.assignee.contains("Bot") || task.assignee.contains("Agent") || task.assignee.contains("Alpha")
                        Icon(
                            imageVector = if (isAiBot) Icons.Default.Face else Icons.Default.AccountCircle,
                            contentDescription = null,
                            tint = PurpleAccentLight,
                            modifier = Modifier.size(12.dp).align(Alignment.Center)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = task.assignee,
                        color = ElegantText,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp
                    )
                }

                // Deadline
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isOverdue) ErrorRed.copy(alpha = 0.15f) else DateBg(task.stage))
                        .border(
                            1.dp, 
                            if (isOverdue) ErrorRed else DateBorder(task.stage), 
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (isOverdue) "OVERDUE" else if (task.stage == "Completed") "COMPLETED" else "$deadlineLabel (${daysRemaining}d left)",
                        color = if (isOverdue) ErrorRed else DateTextColor(task.stage),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 9.sp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = ElegantBorder)
            Spacer(modifier = Modifier.height(8.dp))

            // Stage shifting Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val currentIdx = stages.indexOf(task.stage)
                
                Text(
                    text = "Node Placement: ${task.stage}",
                    style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext, fontSize = 8.sp)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = {
                            if (currentIdx > 0) {
                                onMoveStage(task, stages[currentIdx - 1])
                            }
                        },
                        enabled = currentIdx > 0,
                        colors = ButtonDefaults.buttonColors(containerColor = ElegantBorder, contentColor = ElegantText),
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(width = 44.dp, height = 28.dp)
                    ) {
                        Text("←", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    }

                    Button(
                        onClick = {
                            if (currentIdx < stages.size - 1) {
                                onMoveStage(task, stages[currentIdx + 1])
                            }
                        },
                        enabled = currentIdx < stages.size - 1,
                        colors = ButtonDefaults.buttonColors(containerColor = PurpleAccentLight, contentColor = PurpleAccentHeavy),
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(width = 44.dp, height = 28.dp)
                    ) {
                        Text("→", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}

// Helpers for task states
@Composable
fun DateBg(stage: String): Color {
    return if (stage == "Completed") SuccessGreen.copy(alpha = 0.15f) else ElegantBorder
}

@Composable
fun DateBorder(stage: String): Color {
    return if (stage == "Completed") SuccessGreen else ElegantBorder
}

@Composable
fun DateTextColor(stage: String): Color {
    return if (stage == "Completed") SuccessGreen else ElegantText
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddProjectDialog(
    clients: List<Client>,
    onDismiss: () -> Unit,
    onSave: (Int, String, String, String, Int) -> Unit
) {
    var selectedClientIndex by remember { mutableStateOf(0) }
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var daysStr by remember { mutableStateOf("7") }
    
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("INITIALIZE PROJECT LIFECYCLE", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium) },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("Associated Client Profile", style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext))
                    if (clients.isEmpty()) {
                        Text("No clients found. Post client from Client screen.", color = ErrorRed, style = MaterialTheme.typography.labelSmall)
                    } else {
                        var expandedDropdown by remember { mutableStateOf(false) }
                        val currentClient = clients.getOrNull(selectedClientIndex)
                        
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(ElegantSurface)
                                .border(1.dp, ElegantBorder, RoundedCornerShape(8.dp))
                                .clickable { expandedDropdown = true }
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    currentClient?.company ?: "None Onboarded",
                                    color = Color.White,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = PurpleAccentLight)
                            }
                            
                            DropdownMenu(
                                expanded = expandedDropdown,
                                onDismissRequest = { expandedDropdown = false },
                                modifier = Modifier
                                    .fillMaxWidth(0.8f)
                                    .background(ElegantSurface)
                            ) {
                                clients.forEachIndexed { index, client ->
                                    DropdownMenuItem(
                                        text = { Text(client.company, color = Color.White) },
                                        onClick = {
                                            selectedClientIndex = index
                                            expandedDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Project System Name") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            unfocusedBorderColor = ElegantBorder,
                            focusedBorderColor = PurpleAccentLight,
                            cursorColor = PurpleAccentLight
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("add_project_name_input")
                    )
                }

                item {
                    OutlinedTextField(
                        value = desc,
                        onValueChange = { desc = it },
                        label = { Text("Milestones Outline Description") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            unfocusedBorderColor = ElegantBorder,
                            focusedBorderColor = PurpleAccentLight,
                            cursorColor = PurpleAccentLight
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("add_project_desc_input")
                    )
                }

                item {
                    OutlinedTextField(
                        value = daysStr,
                        onValueChange = { daysStr = it },
                        label = { Text("Days to Complete Goal (Target)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            unfocusedBorderColor = ElegantBorder,
                            focusedBorderColor = PurpleAccentLight,
                            cursorColor = PurpleAccentLight
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("add_project_days_input")
                    )
                }

                if (errorMsg != null) {
                    item {
                        Text(text = errorMsg!!, color = ErrorRed, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val client = clients.getOrNull(selectedClientIndex)
                    val days = daysStr.toIntOrNull()
                    if (client == null) {
                        errorMsg = "An onboarded client contract is necessary."
                    } else if (name.isEmpty() || desc.isEmpty()) {
                        errorMsg = "Please supply name and description details."
                    } else if (days == null || days <= 0) {
                        errorMsg = "Insert a valid timeline duration."
                    } else {
                        onSave(client.id, client.company, name, desc, days)
                    }
                },
                enabled = clients.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = PurpleAccentLight, contentColor = PurpleAccentHeavy),
                modifier = Modifier.testTag("submit_project_button")
            ) {
                Text("Launch Project", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color.White)
            }
        },
        containerColor = ElegantSurface
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTaskDialog(
    projectId: Int,
    onDismiss: () -> Unit,
    onSave: (String, String, String, Int, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var assigneeIndex by remember { mutableStateOf(0) }
    var daysStr by remember { mutableStateOf("3") }
    var stageIndex by remember { mutableStateOf(0) }

    val assignees = listOf("Dev-Agent Alpha", "Support AI Bot", "CRM Optimizer", "Lead Consultant", "Partner Manager")
    val stages = listOf("Todo", "In Forge", "Testing", "Completed")

    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ADD WORK TASK NODE", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium) },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Task Label Title") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            unfocusedBorderColor = ElegantBorder,
                            focusedBorderColor = PurpleAccentLight,
                            cursorColor = PurpleAccentLight
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("add_task_title_input")
                    )
                }

                item {
                    OutlinedTextField(
                        value = desc,
                        onValueChange = { desc = it },
                        label = { Text("Brief Instructions") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            unfocusedBorderColor = ElegantBorder,
                            focusedBorderColor = PurpleAccentLight,
                            cursorColor = PurpleAccentLight
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("add_task_desc_input")
                    )
                }

                item {
                    Text("Select Agent / Team Executor", style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext))
                    var expandedDropdown by remember { mutableStateOf(false) }
                    
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(ElegantSurface)
                            .border(1.dp, ElegantBorder, RoundedCornerShape(8.dp))
                            .clickable { expandedDropdown = true }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                assignees[assigneeIndex],
                                color = Color.White,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = PurpleAccentLight)
                        }
                        
                        DropdownMenu(
                            expanded = expandedDropdown,
                            onDismissRequest = { expandedDropdown = false },
                            modifier = Modifier
                                .fillMaxWidth(0.8f)
                                .background(ElegantSurface)
                        ) {
                            assignees.forEachIndexed { index, name ->
                                DropdownMenuItem(
                                    text = { Text(name, color = Color.White) },
                                    onClick = {
                                        assigneeIndex = index
                                        expandedDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }

                item {
                    Text("Initial Pipeline Placement", style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        stages.forEachIndexed { idx, stg ->
                            val isSelected = stageIndex == idx
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSelected) PurpleAccentLight else Color.Transparent)
                                    .border(1.dp, if (isSelected) PurpleAccentLight else ElegantBorder, RoundedCornerShape(4.dp))
                                    .clickable { stageIndex = idx }
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = stg,
                                    color = if (isSelected) PurpleAccentHeavy else ElegantSubtext,
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = daysStr,
                        onValueChange = { daysStr = it },
                        label = { Text("Days buffer to Complete") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            unfocusedBorderColor = ElegantBorder,
                            focusedBorderColor = PurpleAccentLight,
                            cursorColor = PurpleAccentLight
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("add_task_days_input")
                    )
                }

                if (errorMsg != null) {
                    item {
                        Text(text = errorMsg!!, color = ErrorRed, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val days = daysStr.toIntOrNull()
                    if (title.isEmpty() || desc.isEmpty()) {
                        errorMsg = "Please populate all descriptions."
                    } else if (days == null || days <= 0) {
                        errorMsg = "Set a valid timeline buffer."
                    } else {
                        onSave(title, desc, assignees[assigneeIndex], days, stages[stageIndex])
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PurpleAccentLight, contentColor = PurpleAccentHeavy),
                modifier = Modifier.testTag("submit_task_button")
            ) {
                Text("Align Task Block", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color.White)
            }
        },
        containerColor = ElegantSurface
    )
}
