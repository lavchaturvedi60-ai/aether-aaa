package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsTab(
    logTheme: String,
    onLogThemeChange: (String) -> Unit,
    adMode: String,
    onAdModeChange: (String) -> Unit,
    agencyName: String,
    onAgencyNameChange: (String) -> Unit,
    maxLogLimit: Int,
    onMaxLogLimitChange: (Int) -> Unit,
    onClearLogs: () -> Unit,
    currentPlan: String,
    isBillingYearly: Boolean,
    onPlanChange: (String, Boolean) -> Unit,
    cacheAnswers: Boolean,
    onCacheAnswersChange: (Boolean) -> Unit,
    aiCreativity: Float,
    onAiCreativityChange: (Float) -> Unit,
    geminiModel: String,
    onGeminiModelChange: (String) -> Unit,
    realtimeLogs: Boolean,
    onRealtimeLogsChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var brandInput by remember(agencyName) { mutableStateOf(agencyName) }
    var limitInput by remember(maxLogLimit) { mutableStateOf(maxLogLimit.toString()) }
    
    // Web-grade state integrations
    var stripeConnectorActive by remember { mutableStateOf(true) }
    var odooSyncPort by remember { mutableStateOf("8069") }
    var twilioSmsForwarding by remember { mutableStateOf(false) }

    // Checkout modal helper states
    var showCheckoutModal by remember { mutableStateOf(false) }
    var targetPlanName by remember { mutableStateOf("Silver") }
    var isCheckingOut by remember { mutableStateOf(false) }
    var checkoutSuccess by remember { mutableStateOf(false) }

    // Backup downloader state simulation
    var downloadProgress by remember { mutableStateOf<Float?>(null) }
    var backupStatusText by remember { mutableStateOf("Backup State Ready") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ElegantBg)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        
        // --- Header Section ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "AETHER COGNITIVE SYSTEM SETTINGS",
                    style = MaterialTheme.typography.labelMedium.copy(
                        letterSpacing = 1.5.sp,
                        color = PurpleAccentLight,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "Configure subscription models, system caches, and active webhooks",
                    style = MaterialTheme.typography.bodySmall.copy(color = ElegantSubtext)
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF131215))
                    .border(1.dp, ElegantBorder, RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "v2.4-cognitive",
                    color = PurpleAccentLight,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // --- Subscription Tiers & Billing Matrix ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, PurpleAccentMuted, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = ElegantSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = WarningOrange, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            "Licensing & Subscription Nodes",
                            style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(30.dp))
                            .background(
                                if (currentPlan == "Free") WarningOrange.copy(alpha = 0.15f) 
                                else SuccessGreen.copy(alpha = 0.15f)
                            )
                            .border(
                                1.dp, 
                                if (currentPlan == "Free") WarningOrange else SuccessGreen, 
                                RoundedCornerShape(30.dp)
                            )
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (currentPlan == "Free") "FREE WITH SPONSORS" else "$currentPlan ACTIVE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (currentPlan == "Free") WarningOrange else SuccessGreen, 
                                fontWeight = FontWeight.ExtraBold
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Switch between dynamic automated plans. Unlocked properties apply limits instantly to the running workspace engine and log buffer capacity.",
                    color = ElegantSubtext,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Billing Period Toggle
                Row(
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .clip(RoundedCornerShape(30.dp))
                        .background(Color(0xFF131215))
                        .border(1.dp, ElegantBorder, RoundedCornerShape(30.dp))
                        .padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(30.dp))
                            .background(if (!isBillingYearly) PurpleAccentHeavy else Color.Transparent)
                            .clickable { onPlanChange(currentPlan, false) }
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Text("Monthly Cycle", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(30.dp))
                            .background(if (isBillingYearly) PurpleAccentHeavy else Color.Transparent)
                            .clickable { onPlanChange(currentPlan, true) }
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Annual Cycle", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(4.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(SuccessGreen)
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text("SAVE", color = Color.Black, fontSize = 8.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Plan Grid Cards
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    val plans = listOf(
                        Triple("Free", "Free Broadcasts", "Sponsor-supported nodes, 2 Clients max, 3 workflows limit, slow query throttle."),
                        Triple("Silver", "Premium Silver", "Ad-Free experience, 5 Clients limit, 6 workflows limit, obsidian & amber themes, standard priority."),
                        Triple("Gold", "Pro Gold Tier", "Ad-Free experience, 15 Clients limit, 20 workflows limit, temperature modifier, Matrix Green log themes."),
                        Triple("Max", "VIP Agency Max", "Ad-Free experience, custom Agency naming overrides, unlimited clients & workflows, immediate cache outcomes, priority VIP support.")
                    )

                    plans.forEach { (key, name, desc) ->
                        val isSelected = currentPlan == key
                        val activeCost = when (key) {
                            "Free" -> "$0"
                            "Silver" -> if (isBillingYearly) "$8 / Yr" else "$1 / Mo"
                            "Gold" -> if (isBillingYearly) "$18 / Yr" else "$2 / Mo"
                            else -> if (isBillingYearly) "$38 / Yr" else "$4 / Mo"
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) PurpleAccentHeavy.copy(alpha = 0.2f) else Color.Transparent)
                                .border(
                                    2.dp, 
                                    if (isSelected) PurpleAccentLight else ElegantBorder.copy(alpha = 0.6f), 
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    if (key == "Free") {
                                        onPlanChange("Free", isBillingYearly)
                                    } else {
                                        targetPlanName = key
                                        showCheckoutModal = true
                                    }
                                }
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = {
                                            if (key == "Free") {
                                                onPlanChange("Free", isBillingYearly)
                                            } else {
                                                targetPlanName = key
                                                showCheckoutModal = true
                                            }
                                        },
                                        colors = RadioButtonDefaults.colors(selectedColor = PurpleAccentLight, unselectedColor = ElegantSubtext)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column {
                                        Text(name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(desc, color = ElegantSubtext, fontSize = 11.sp, lineHeight = 14.sp)
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131215)),
                                    border = BorderStroke(1.dp, ElegantBorder)
                                ) {
                                    Text(
                                        text = activeCost,
                                        color = PurpleAccentLight,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- Brand Identity Console Override ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ElegantBorder, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = ElegantSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = PurpleAccentLight, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Agency Branding Node",
                        style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    "Assign custom title headers over the main workspace command terminals. Custom brand identity overrides require VIP Agency Max tier validation.",
                    color = ElegantSubtext,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                
                OutlinedTextField(
                    value = brandInput,
                    onValueChange = {
                        brandInput = it
                        onAgencyNameChange(it)
                    },
                    label = { Text("Agency Name Overlay", color = ElegantSubtext) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ElegantText,
                        unfocusedTextColor = ElegantText,
                        unfocusedBorderColor = ElegantBorder,
                        focusedBorderColor = PurpleAccentLight,
                        cursorColor = PurpleAccentLight
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("setting_agency_name_input")
                )
                if (currentPlan != "Max") {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = WarningOrange, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "[Brand Protection Enabled]: Upgrade to VIP Max to override company identity.",
                            color = WarningOrange,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // --- Web-Grade AI Configurations (As many as on any AI Automation website!) ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ElegantBorder, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = ElegantSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Build, contentDescription = null, tint = PurpleAccentLight, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Enterprise AI Engine Controls",
                        style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                    )
                }
                Spacer(modifier = Modifier.height(14.dp))

                // Toggle 1: Cache Answers
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Pre-compiled Caching (Fast Answers)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Uses Cognitive Warm-Start to bypass remote latency rules and resolve recurring queries instantly.", color = ElegantSubtext, fontSize = 10.sp, lineHeight = 13.sp)
                    }
                    Switch(
                        checked = cacheAnswers,
                        onCheckedChange = { onCacheAnswersChange(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = PurpleAccentLight, checkedTrackColor = PurpleAccentMuted)
                    )
                }
                Divider(color = ElegantBorder, modifier = Modifier.padding(vertical = 12.dp))

                // Toggle 2: AI Creativity Temperature Sliders
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Cognitive Creative Temp: $aiCreativity", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Lower temperates produce strict event audits; higher temperatures enable creative automation pitches.", color = ElegantSubtext, fontSize = 10.sp, lineHeight = 13.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Slider(
                        value = aiCreativity,
                        onValueChange = { onAiCreativityChange(it) },
                        valueRange = 0.1f..1.0f,
                        colors = SliderDefaults.colors(thumbColor = PurpleAccentLight, activeTrackColor = PurpleAccentLight)
                    )
                }
                Divider(color = ElegantBorder, modifier = Modifier.padding(vertical = 12.dp))

                // Select: AI LLM Engines
                Column {
                    Text("Selected Large Language Model (Core)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    val models = listOf("Gemini-3.5-flash", "Gemini-2.5-pro", "Aether-Cognitive-V3 (Local Sandbox)")
                    models.forEach { model ->
                        val isSel = geminiModel == model
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSel) Color(0xFF1B1A1E) else Color.Transparent)
                                .border(1.dp, if (isSel) PurpleAccentLight else ElegantBorder.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                .clickable { onGeminiModelChange(model) }
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(model, color = if (isSel) Color.White else ElegantSubtext, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            if (isSel) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = PurpleAccentLight, modifier = Modifier.size(12.dp))
                            }
                        }
                    }
                }
                Divider(color = ElegantBorder, modifier = Modifier.padding(vertical = 12.dp))

                // Toggle 3: Realtime Logs Streams
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Active Sandbox Logger stream", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Simulates reactive terminal printing for workflows executed on background processors.", color = ElegantSubtext, fontSize = 10.sp)
                    }
                    Switch(
                        checked = realtimeLogs,
                        onCheckedChange = { onRealtimeLogsChange(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = PurpleAccentLight, checkedTrackColor = PurpleAccentMuted)
                    )
                }

                Divider(color = ElegantBorder, modifier = Modifier.padding(vertical = 12.dp))

                // Web-grade connectors toggles
                Text("Simulated External APIs Integration", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Stripe secure Webhook dispatchers", color = ElegantSubtext, fontSize = 11.sp)
                    Switch(
                        checked = stripeConnectorActive,
                        onCheckedChange = { stripeConnectorActive = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = PurpleAccentLight)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Twilio SMS Diagnostic Alerts", color = ElegantSubtext, fontSize = 11.sp)
                    Switch(
                        checked = twilioSmsForwarding,
                        onCheckedChange = { twilioSmsForwarding = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = PurpleAccentLight)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = odooSyncPort,
                    onValueChange = { odooSyncPort = it },
                    label = { Text("Odoo Legacy RPC sync port listener", color = ElegantSubtext, fontSize = 10.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ElegantText,
                        unfocusedTextColor = ElegantText,
                        focusedBorderColor = PurpleAccentLight,
                        unfocusedBorderColor = ElegantBorder
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
            }
        }

        // --- Terminal Visual Themes Select ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ElegantBorder, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = ElegantSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.List, contentDescription = null, tint = PurpleAccentLight, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Command-Center Terminal Theme",
                        style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                val customThemes = listOf(
                    Triple("Obsidian", "Carbon Obsidian Mono", Color(0xFFD0BCFF)),
                    Triple("Amber", "Retro Amber Cathode", Color(0xFFFFAB40)),
                    Triple("Matrix", "Green Matrix Code rain", Color(0xFF00E676)),
                    Triple("Cyberpunk", "Tokyo Cyberpunk Neon Aura", Color(0xFFFF5252))
                )

                customThemes.forEach { (key, title, previewColor) ->
                    val isSelected = logTheme == key
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) PurpleAccentHeavy.copy(alpha = 0.25f) else Color.Transparent)
                            .border(1.dp, if (isSelected) PurpleAccentLight else ElegantBorder.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                            .clickable { onLogThemeChange(key) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(previewColor)
                             )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = title,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = if (isSelected) Color.White else ElegantText,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            )
                        }
                        if (isSelected) {
                            Icon(Icons.Default.Check, contentDescription = "Active", tint = PurpleAccentLight, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // --- Local Packaging Console Widgets (Download without PC!) ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, PurpleAccentLight, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = ElegantBg)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        "Export Mobile App Console (No PC Required)",
                        style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Aether Agency OS compiled package outputs are preserved locally. You can download this application configuration database directly onto your phone without connecting to any external computer or PC.",
                    color = ElegantSubtext,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
                Spacer(modifier = Modifier.height(14.dp))

                // Simulated Exporter Action
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF131215))
                        .border(1.dp, ElegantBorder, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Aether_System_Bundle_Backup.json", color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                Text(backupStatusText, color = ElegantSubtext, fontSize = 10.sp)
                            }
                            Button(
                                onClick = {
                                    downloadProgress = 0.01f
                                    backupStatusText = "Hashing backup nodes..."
                                    // Start a mock download sweep
                                    var count = 0
                                    val t = java.util.Timer()
                                    t.scheduleAtFixedRate(object : java.util.TimerTask() {
                                        override fun run() {
                                            count++
                                            downloadProgress = (count / 10f).coerceAtMost(1.0f)
                                            if (count >= 10) {
                                                backupStatusText = "Bundle Backup Saved to Files/Aether-OS-Bundles!"
                                                t.cancel()
                                            }
                                        }
                                    }, 100L, 200L)
                                },
                                enabled = downloadProgress == null,
                                colors = ButtonDefaults.buttonColors(containerColor = PurpleAccentLight, contentColor = PurpleAccentText)
                            ) {
                                Text("Download Bundle", fontSize = 11.sp)
                            }
                        }
                        if (downloadProgress != null) {
                            Spacer(modifier = Modifier.height(10.dp))
                            LinearProgressIndicator(
                                progress = downloadProgress ?: 0f,
                                modifier = Modifier.fillMaxWidth(),
                                color = SuccessGreen,
                                trackColor = ElegantBorder
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(14.dp))
                
                // Detailed instructions for APK compilation download
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1B1822))
                        .border(1.dp, PurpleAccentMuted, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "📱 DOWNLOAD APPLICATION APK TO YOUR MOBILE DIRECTLY:",
                            color = PurpleAccentLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        val bulletPoints = listOf(
                            "Compile the apk package in the cloud right now using the system's online compilator tool.",
                            "Check the top settings dropdown of your streaming browser viewer screen.",
                            "Tap 'Export ZIP / Build APK package'. No PC, no cable, and no development files are needed on your end!",
                            "Scan the compiled QR code with your phone camera to download directly."
                        )
                        bulletPoints.forEach { point ->
                            Row(
                                modifier = Modifier.padding(vertical = 3.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Text("•", color = SuccessGreen, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(end = 6.dp))
                                Text(point, color = Color.White, fontSize = 11.sp, lineHeight = 15.sp)
                            }
                        }
                    }
                }
            }
        }

        // --- Log Truncation Operations ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ElegantBorder, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = ElegantSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Settings, contentDescription = null, tint = PurpleAccentLight, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Console Tuning",
                        style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = limitInput,
                    onValueChange = {
                        limitInput = it
                        val num = it.toIntOrNull()
                        if (num != null && num > 0) {
                            onMaxLogLimitChange(num)
                        }
                    },
                    label = { Text("Log Buffer Retention Limit", color = ElegantSubtext) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ElegantText,
                        unfocusedTextColor = ElegantText,
                        unfocusedBorderColor = ElegantBorder,
                        focusedBorderColor = PurpleAccentLight,
                        cursorColor = PurpleAccentLight
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("setting_log_limit_input")
                )
                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onClearLogs,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ErrorRed.copy(alpha = 0.2f),
                        contentColor = ErrorRed
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ErrorRed, RoundedCornerShape(8.dp))
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Truncate Live Logs Database", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }

    // --- Simulated Checkout Modal Sheet (Strictly Flat Price, No Taxes!) ---
    if (showCheckoutModal) {
        val calculatedCost = when (targetPlanName) {
            "Silver" -> if (isBillingYearly) 8.00 else 1.00
            "Gold" -> if (isBillingYearly) 18.00 else 2.00
            else -> if (isBillingYearly) 38.00 else 4.00
        }
        val displayFrequency = if (isBillingYearly) "Annual Plan Cycles" else "Monthly Cycles"

        AlertDialog(
            onDismissRequest = {
                if (!isCheckingOut) {
                    showCheckoutModal = false
                    checkoutSuccess = false
                }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = SuccessGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Aether Automated Gateway",
                        style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.ExtraBold)
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        text = "Authorized token routing pipeline running directly over cognitive simulation chains to allocate dynamic priority speeds.",
                        style = MaterialTheme.typography.bodySmall.copy(color = ElegantSubtext, lineHeight = 14.sp)
                    )
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, ElegantBorder, RoundedCornerShape(8.dp)),
                        colors = CardDefaults.cardColors(containerColor = ElegantBg)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Upgrade to $targetPlanName License", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
                                Text("$${calculatedCost}0", color = SuccessGreen, fontWeight = FontWeight.Black, fontSize = 13.sp)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Billing Frequency: $displayFrequency", color = ElegantSubtext, fontSize = 11.sp)
                            
                            // Highly detailed verification that NO tax inputs exist
                            Divider(color = ElegantBorder.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Core Licensing Fees", color = ElegantSubtext, fontSize = 11.sp)
                                Text("$${calculatedCost}0", color = Color.White, fontSize = 11.sp)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Surcharge / Tax options", color = ElegantSubtext, fontSize = 11.sp)
                                Text("$0.00 (Exempt / Not Available)", color = WarningOrange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Unified Flat Rate Total", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("$${calculatedCost}0", color = SuccessGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (isCheckingOut) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = PurpleAccentLight)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Negotiating secure client ledger keys...", style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext))
                            }
                        }
                    } else if (checkoutSuccess) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SuccessGreen.copy(alpha = 0.1f))
                                .border(1.dp, SuccessGreen, RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Payment Processed! subscription changed successfully.", color = SuccessGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            confirmButton = {
                if (!checkoutSuccess) {
                    Button(
                        onClick = {
                            isCheckingOut = true
                            // Simulate secure checkout delay
                            val handler = android.os.Handler(android.os.Looper.getMainLooper())
                            handler.postDelayed({
                                isCheckingOut = false
                                checkoutSuccess = true
                                onPlanChange(targetPlanName, isBillingYearly)
                            }, 1800)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen, contentColor = Color.Black),
                        enabled = !isCheckingOut
                    ) {
                        Text("Simulate Gateway Checkout", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = {
                            showCheckoutModal = false
                            checkoutSuccess = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PurpleAccentLight, contentColor = PurpleAccentText)
                    ) {
                        Text("Complete Activation", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                if (!isCheckingOut) {
                    TextButton(onClick = { showCheckoutModal = false }) {
                        Text("Dismiss Gateway", color = ElegantSubtext)
                    }
                }
            },
            containerColor = ElegantSurface,
            shape = RoundedCornerShape(16.dp)
        )
    }
}
