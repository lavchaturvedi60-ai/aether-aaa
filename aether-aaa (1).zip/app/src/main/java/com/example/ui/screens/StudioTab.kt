package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.AutomationWorkflow
import com.example.data.local.entity.Client
import com.example.ui.theme.*
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioTab(
    clients: List<Client>,
    workflows: List<AutomationWorkflow>,
    isGenerating: Boolean,
    coPilotResponse: String?,
    isSimulating: Int?,
    onAddWorkflow: (Int, String, String, String, String, String) -> Unit,
    onDeleteWorkflow: (AutomationWorkflow) -> Unit,
    onUpdateStatus: (AutomationWorkflow, String) -> Unit,
    onSimulateRun: (AutomationWorkflow) -> Unit,
    onGenWorkflowText: (String, String?) -> Unit,
    onResetCopilot: () -> Unit,
    onPostLog: (Int, String, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedClientIndex by remember { mutableStateFlowOf(0) }
    var activeStudioMode by remember { mutableStateFlowOf("WORKFLOWS") } // "WORKFLOWS", "TEMPLATES" or "AI_CO_BUILDER"
    
    var showAddWorkflowDialog by remember { mutableStateFlowOf(false) }
    var aiIntentText by remember { mutableStateFlowOf("") }

    val currentClient = clients.getOrNull(selectedClientIndex)
    val clientWorkflows = if (currentClient != null) {
        workflows.filter { it.clientId == currentClient.id }
    } else {
        workflows
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ElegantBg)
            .padding(16.dp)
    ) {
        // --- Tab mode toggler (Workflows vs Templates vs AI Architect) ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(ElegantSurface)
                .padding(4.dp)
        ) {
            Button(
                onClick = { 
                    activeStudioMode = "WORKFLOWS"
                    onResetCopilot()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeStudioMode == "WORKFLOWS") PurpleAccentHeavy else Color.Transparent,
                    contentColor = if (activeStudioMode == "WORKFLOWS") Color.White else ElegantSubtext
                ),
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("Pipelines", style = MaterialTheme.typography.labelSmall, maxLines = 1)
            }

            Button(
                onClick = { 
                    activeStudioMode = "TEMPLATES"
                    onResetCopilot()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeStudioMode == "TEMPLATES") PurpleAccentHeavy else Color.Transparent,
                    contentColor = if (activeStudioMode == "TEMPLATES") Color.White else ElegantSubtext
                ),
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("Templates", style = MaterialTheme.typography.labelSmall, maxLines = 1)
            }
            
            Button(
                onClick = { activeStudioMode = "AI_CO_BUILDER" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeStudioMode == "AI_CO_BUILDER") PurpleAccentHeavy else Color.Transparent,
                    contentColor = if (activeStudioMode == "AI_CO_BUILDER") Color.White else ElegantSubtext
                ),
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("AI Architect", style = MaterialTheme.typography.labelSmall, maxLines = 1)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (activeStudioMode == "TEMPLATES") {
            TemplatesTab(
                clients = clients,
                onDeployWorkflow = onAddWorkflow,
                onPostLog = onPostLog,
                modifier = Modifier.weight(1.0f)
            )
        } else if (activeStudioMode == "WORKFLOWS") {
            // --- DROPDOWN SELECT CLIENT ---
            if (clients.isNotEmpty()) {
                var dropdownExpanded by remember { mutableStateFlowOf(false) }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(ElegantSurface)
                        .border(1.dp, ElegantBorder, RoundedCornerShape(8.dp))
                        .clickable { dropdownExpanded = true }
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("ACTIVE WORKSPACE CLIENT", style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext))
                            Text(
                                text = currentClient?.company ?: "None Selected",
                                style = MaterialTheme.typography.titleMedium.copy(color = ElegantText, fontWeight = FontWeight.Bold)
                            )
                        }
                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Select client", tint = PurpleAccentLight)
                    }

                    DropdownMenu(
                        expanded = dropdownExpanded,
                        onDismissRequest = { dropdownExpanded = false },
                        modifier = Modifier
                            .fillMaxWidth(0.9f)
                            .background(ElegantSurface)
                            .border(1.dp, ElegantBorder, RoundedCornerShape(8.dp))
                    ) {
                        clients.forEachIndexed { idx, client ->
                            DropdownMenuItem(
                                text = { Text(client.company, color = ElegantText, style = MaterialTheme.typography.bodyMedium) },
                                onClick = {
                                    selectedClientIndex = idx
                                    dropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(ElegantSurface)
                        .border(1.dp, ElegantBorder, RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Onboard a client in the Client tab to build custom workflows.",
                        style = MaterialTheme.typography.bodySmall.copy(color = ElegantSubtext),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Workflows header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Deployed Integration Blueprints",
                    style = MaterialTheme.typography.titleSmall.copy(color = ElegantSubtext, fontWeight = FontWeight.Bold)
                )
                if (currentClient != null) {
                    TextButton(
                        onClick = { showAddWorkflowDialog = true },
                        colors = ButtonDefaults.textButtonColors(contentColor = PurpleAccentLight)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Workflow Pipeline", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Workflows list
            if (clientWorkflows.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1.0f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(ElegantSurface)
                        .border(1.dp, ElegantBorder, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                        Icon(Icons.Default.Build, contentDescription = null, tint = ElegantSubtext, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No step workflows connected yet", style = MaterialTheme.typography.titleSmall.copy(color = ElegantText))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Odoo dynamic modules deploy instantly. Tap 'Add Workflow Pipeline' above or use 'AI Studio Architect' to generate custom code nodes instantly.",
                            style = MaterialTheme.typography.bodySmall.copy(color = ElegantSubtext),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1.0f),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(clientWorkflows, key = { it.id }) { workflow ->
                        WorkflowStudioCard(
                            workflow = workflow,
                            isSimulating = isSimulating == workflow.id,
                            onSimulateRun = { onSimulateRun(workflow) },
                            onDelete = { onDeleteWorkflow(workflow) },
                            onUpdateStatus = { newStatus -> onUpdateStatus(workflow, newStatus) }
                        )
                    }
                }
            }
        } else {
            // --- AI STUDIO CO-BUILDER TAB ---
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.0f),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().border(1.dp, ElegantBorder, RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = ElegantSurface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(PurpleAccentHeavy)
                                ) {
                                    Icon(Icons.Default.Face, contentDescription = null, tint = PurpleAccentLight, modifier = Modifier.align(Alignment.Center))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("AETHER SOLUTIONS ARCHITECT", style = MaterialTheme.typography.titleSmall.copy(color = ElegantText, fontWeight = FontWeight.Bold))
                                    Text("Generate custom node-link blueprints & scripts.", style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext))
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            
                            OutlinedTextField(
                                value = aiIntentText,
                                onValueChange = { aiIntentText = it },
                                label = { Text("What automation do you want to build?") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = ElegantText,
                                    unfocusedTextColor = ElegantText,
                                    unfocusedBorderColor = ElegantBorder,
                                    focusedBorderColor = PurpleAccentLight,
                                    cursorColor = PurpleAccentLight
                                ),
                                placeholder = { Text("E.g., Read invoice files from Twilio MMS message, call Gemini-3.5-flash to extract items, write results directly to Firestore DB and message CRM slack alerts.", color = ElegantSubtext, fontSize = 12.sp) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                                    .testTag("automation_intent_input")
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = { 
                                    if (aiIntentText.isNotEmpty()) {
                                        onGenWorkflowText(aiIntentText, currentClient?.company)
                                    }
                                },
                                enabled = !isGenerating && aiIntentText.isNotEmpty(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = PurpleAccentLight,
                                    contentColor = PurpleAccentText,
                                    disabledContainerColor = PurpleAccentLight.copy(alpha = 0.5f)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("ai_generate_flow_button")
                            ) {
                                if (isGenerating) {
                                    CircularProgressIndicator(color = PurpleAccentText, modifier = Modifier.size(24.dp))
                                } else {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Generate Premium Custom Pipeline", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                if (coPilotResponse != null) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, PurpleAccentLight.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF131215))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        "CO-PILOT GENERATION MANIFEST",
                                        style = MaterialTheme.typography.titleSmall.copy(color = PurpleAccentLight, fontWeight = FontWeight.Black)
                                    )
                                    IconButton(onClick = onResetCopilot) {
                                        Icon(Icons.Default.Refresh, contentDescription = "Clear", tint = ElegantSubtext)
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Divider(color = ElegantBorder)
                                Spacer(modifier = Modifier.height(12.dp))
                                
                                Text(
                                    text = coPilotResponse,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = ElegantText,
                                        lineHeight = 22.sp,
                                        fontFamily = if (coPilotResponse.contains("python") || coPilotResponse.contains("class")) FontFamily.Monospace else FontFamily.Default
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Add Manual Workflow Dialog
        if (showAddWorkflowDialog && currentClient != null) {
            AddWorkflowDialog(
                clientName = currentClient.company,
                onDismiss = { showAddWorkflowDialog = false },
                onSave = { name, desc, trigger, steps ->
                    onAddWorkflow(currentClient.id, currentClient.company, name, desc, trigger, steps)
                    showAddWorkflowDialog = false
                }
            )
        }
    }
}

@Composable
fun WorkflowStudioCard(
    workflow: AutomationWorkflow,
    isSimulating: Boolean,
    onSimulateRun: () -> Unit,
    onDelete: () -> Unit,
    onUpdateStatus: (String) -> Unit
) {
    val stepsList = workflow.steps.split(",")
    var isExpanded by remember { mutableStateFlowOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, ElegantBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = ElegantSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Name, trigger type
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1.0f)) {
                    Text(
                        text = workflow.name,
                        style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Trigger Event: [${workflow.triggerType}]",
                        style = MaterialTheme.typography.labelSmall.copy(color = PurpleAccentLight)
                    )
                }

                // Status Toggler
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (workflow.status == "Active") SuccessGreen.copy(alpha = 0.15f) else ElegantSubtext.copy(alpha = 0.15f))
                        .border(1.dp, if (workflow.status == "Active") SuccessGreen.copy(alpha = 0.4f) else ElegantSubtext.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                        .clickable {
                            val newStatus = if (workflow.status == "Active") "Paused" else "Active"
                            onUpdateStatus(newStatus)
                        }
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = workflow.status.uppercase(),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (workflow.status == "Active") SuccessGreen else ElegantSubtext,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = workflow.description,
                style = MaterialTheme.typography.bodySmall.copy(color = ElegantSubtext),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            // Dynamic Step diagrams (The Flow Diagram Nodes)
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded }
                    .background(Color(0xFF131215), RoundedCornerShape(8.dp))
                    .border(1.dp, ElegantBorder, RoundedCornerShape(8.dp))
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Build, contentDescription = null, tint = PurpleAccentLight, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "View Node-Link Pipeline (${stepsList.size} blocks)",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold)
                    )
                }
                Icon(
                    imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = null,
                    tint = ElegantSubtext
                )
            }

            // Expose Visual Pipelines Nodes
            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    stepsList.forEachIndexed { idx, step ->
                        val isTrigger = idx == 0
                        val isAI = step.contains("Gemini") || step.contains("Classifier")
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.9f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    when {
                                        isTrigger -> Color(0xFF2B2930)
                                        isAI -> PurpleAccentHeavy.copy(alpha = 0.2f)
                                        else -> Color(0xFF131215)
                                    }
                                )
                                .border(
                                    width = 1.dp,
                                    color = when {
                                        isTrigger -> ElegantBorder
                                        isAI -> PurpleAccentHeavy
                                        else -> ElegantBorder
                                    },
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .padding(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                              ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clip(CircleShape)
                                            .background(if (isTrigger) PurpleAccentLight else if (isAI) PurpleAccentHeavy else ElegantSubtext)
                                    ) {
                                        Text(
                                            text = (idx + 1).toString(),
                                            color = if (isTrigger) PurpleAccentText else Color.White,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.align(Alignment.Center)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = step.trim(),
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                                Text(
                                    text = if (isTrigger) "TRIGGER" else if (isAI) "COGNITIVE" else "INTEGRATION",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 8.sp,
                                        color = if (isTrigger) PurpleAccentLight else if (isAI) PurpleAccentLight else ElegantSubtext,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }

                        if (idx < stepsList.size - 1) {
                            Text(
                                text = "↓",
                                color = PurpleAccentLight.copy(alpha = 0.6f),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = ElegantBorder)
            Spacer(modifier = Modifier.height(12.dp))

            // Run metric counters & Testing simulation Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("API HITS: ${workflow.apiCallsCount}", style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext))
                    Text(
                        "HEALTH: ${String.format(Locale.getDefault(), "%.1f", workflow.successRate * 100)}%",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (workflow.successRate > 0.95f) SuccessGreen else WarningOrange,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete workflow", tint = ElegantSubtext.copy(alpha = 0.5f))
                    }
                    
                    Button(
                        onClick = onSimulateRun,
                        enabled = !isSimulating,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PurpleAccentLight,
                            contentColor = PurpleAccentText,
                            disabledContainerColor = PurpleAccentLight.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier.testTag("simulate_run_button")
                    ) {
                        if (isSimulating) {
                            CircularProgressIndicator(color = PurpleAccentText, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Running Node...", style = MaterialTheme.typography.labelSmall)
                        } else {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Run", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Test Flow Run", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddWorkflowDialog(
    clientName: String,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String) -> Unit
) {
    var name by remember { mutableStateFlowOf("") }
    var desc by remember { mutableStateFlowOf("") }
    var trigger by remember { mutableStateFlowOf("Webhook") }
    var stepsStr by remember { mutableStateFlowOf("") }
    
    var errorMsg by remember { mutableStateFlowOf<String?>(null) }
    
    val triggerOptions = listOf("Webhook", "Email Received", "Schedule", "Form Saved")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("CREATE HIGH-SPEED PIPELINE", color = ElegantText, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("SOW Client: $clientName", style = MaterialTheme.typography.labelSmall.copy(color = PurpleAccentLight))
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Workflow Name") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ElegantText,
                        unfocusedTextColor = ElegantText,
                        unfocusedBorderColor = ElegantBorder,
                        focusedBorderColor = PurpleAccentLight,
                        cursorColor = PurpleAccentLight
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("workflow_name_input")
                )

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Brief Description of Task") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ElegantText,
                        unfocusedTextColor = ElegantText,
                        unfocusedBorderColor = ElegantBorder,
                        focusedBorderColor = PurpleAccentLight,
                        cursorColor = PurpleAccentLight
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("workflow_desc_input")
                )

                Text("Activation Event trigger", style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    triggerOptions.forEach { t ->
                        val isSelected = trigger == t
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) PurpleAccentLight else Color.Transparent)
                                .border(1.dp, if (isSelected) PurpleAccentLight else ElegantBorder, RoundedCornerShape(4.dp))
                                .clickable { trigger = t }
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = t,
                                color = if (isSelected) PurpleAccentText else ElegantSubtext,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = stepsStr,
                    onValueChange = { stepsStr = it },
                    label = { Text("Module Steps (comma separated)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ElegantText,
                        unfocusedTextColor = ElegantText,
                        unfocusedBorderColor = ElegantBorder,
                        focusedBorderColor = PurpleAccentLight,
                        cursorColor = PurpleAccentLight
                    ),
                    placeholder = { Text("e.g. Webhook, Gemini OCR Manifest, Stripe Ledger Link, Slack dispatch router", color = ElegantSubtext, fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth().testTag("workflow_steps_input")
                )

                if (errorMsg != null) {
                    Text(text = errorMsg!!, color = ErrorRed, style = MaterialTheme.typography.labelSmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isEmpty() || desc.isEmpty() || stepsStr.isEmpty()) {
                        errorMsg = "Please populate all parameters."
                    } else {
                        onSave(name, desc, trigger, stepsStr)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PurpleAccentLight, contentColor = PurpleAccentText),
                modifier = Modifier.testTag("submit_workflow_button")
            ) {
                Text("Build Workflow", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = ElegantText)
            }
        },
        containerColor = ElegantSurface
    )
}
