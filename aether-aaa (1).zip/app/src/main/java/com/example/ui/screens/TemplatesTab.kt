package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.Client
import com.example.ui.theme.*

data class WorkflowTemplate(
    val id: String,
    val category: String, // "Data Entry", "Customer Support", "Social Media", "Report Generation"
    val name: String,
    val description: String,
    val defaultSteps: String,
    val defaultTrigger: String,
    val insights: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TemplatesTab(
    clients: List<Client>,
    onDeployWorkflow: (Int, String, String, String, String, String) -> Unit,
    onPostLog: (Int, String, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf("ALL") }
    var selectedTemplateForDeployment by remember { mutableStateOf<WorkflowTemplate?>(null) }
    var showDeploySuccessMessage by remember { mutableStateOf<String?>(null) }

    val categories = listOf("ALL", "Data Entry", "Customer Support", "Social Media", "Reports")

    val templates = remember {
        listOf(
            WorkflowTemplate(
                id = "t_invoice_ocr",
                category = "Data Entry",
                name = "Invoice Extractor & ERP Sync",
                description = "Monitors email/folder files, extracts invoice fields with Gemini, and publishes them into the workspace ledger ledger rows.",
                defaultSteps = "Trigger:Email Influx,Action:PDF Document extractor,Action:Gemini OCR Parser,Action:Sync Ledger write,Action:Log Dispatch Alert",
                defaultTrigger = "Email Received",
                insights = "Replaces 2 hours of manual entry per contract with instant, structured JSON parsing."
            ),
            WorkflowTemplate(
                id = "t_sku_catalog",
                category = "Data Entry",
                name = "E-Commerce SKU Sync Engine",
                description = "Automates data scraping from merchant XLS catalogs, standardizes categorization fields, and populates cloud inventory DBs.",
                defaultSteps = "Trigger:Webhook,Action:File Stream Parser,Action:SKU Classifier Bot,Action:DB Upload Connector",
                defaultTrigger = "Webhook",
                insights = "Speeds up wholesale merchant catalog inventory mapping by 24x."
            ),
            WorkflowTemplate(
                id = "t_voice_fhir",
                category = "Customer Support",
                name = "Healthcare Voice-EHR Link",
                description = "Transforms medical voicemails into secure EHR slots, executing calendar node conflicts validations.",
                defaultSteps = "Trigger:Webhook,Action:Aether Audio Ingestion,Action:Gemini Medical Entity Extractor,Action:Google Calendar FHIR Bookings",
                defaultTrigger = "Webhook",
                insights = "Maintains 99.1% diagnostic alignment checking doctor schedules automatically."
            ),
            WorkflowTemplate(
                id = "t_faq_agent",
                category = "Customer Support",
                name = "FAQ Semantic Auto-Responder",
                description = "Listens to support lines/Slack feeds, reviews company documentation, and responds instantly to recurring tech issues.",
                defaultSteps = "Trigger:Webhook,Action:Vector HelpDB Query,Action:Gemini Customizer,Action:Slack Dispatch Output",
                defaultTrigger = "Webhook",
                insights = "Deflects up to 64% of support tickets before manual consultant redirection is needed."
            ),
            WorkflowTemplate(
                id = "t_copywriter",
                category = "Social Media",
                name = "Executive LinkedIn Content Ingestion",
                description = "Tracks local operations updates or Raw audio voice briefs, synthesizing structured newsletters and LinkedIn scheduled copies.",
                defaultSteps = "Trigger:Form Saved,Action:Audio Voice Transcriber,Action:Gemini Copywriting Architect,Action:Buffer Scheduler API",
                defaultTrigger = "Form Saved",
                insights = "Generate highly technical business articles and posts from mere 60s voice prompts."
            ),
            WorkflowTemplate(
                id = "t_sentiment_lead",
                category = "Social Media",
                name = "Ad Inbound Sentiment Router",
                description = "Parses online customer leads comments/forms, scores commercial intent, and forwards hot leads immediately via priority SMS.",
                defaultSteps = "Trigger:Form Saved,Action:Prospect Intent Classifier,Action:Gemini Heat Map Scorer,Action:Twilio SMS Priority Alert",
                defaultTrigger = "Form Saved",
                insights = "Prevents hot leads from turning cold. Action time drops from 3 hours to 10 seconds."
            ),
            WorkflowTemplate(
                id = "t_executive_audit",
                category = "Reports",
                name = "Monthly Contract Retainer Auditor",
                description = "Aggregates CRM work log sheets, queries success metrics counters, and builds client-friendly progress PDF summaries.",
                defaultSteps = "Trigger:Schedule,Action:Task Progress Aggregator,Action:Gemini Executive Summarizer,Action:Email Client Dispatcher",
                defaultTrigger = "Schedule",
                insights = "Automates agency accounting logs, highlighting precise ROI gains to clients."
            ),
            WorkflowTemplate(
                id = "t_ledger_reconciliation",
                category = "Reports",
                name = "Stripe Stripe Ledger Cross-Auditor",
                description = "Reconciles inbound Stripe transaction webhooks against DB invoices to locate leakage or billing sync gaps.",
                defaultSteps = "Trigger:Webhook,Action:Invoice DB Fetch,Action:Payment Integrity Checker,Action:Warning Dispatcher Node",
                defaultTrigger = "Webhook",
                insights = "Pinpoints currency differences and sync misalignments instantaneously, saving accounting overhead."
            )
        )
    }

    val filteredTemplates = if (selectedCategory == "ALL") {
        templates
    } else {
        templates.filter { it.category.equals(selectedCategory, ignoreCase = true) || (selectedCategory == "Reports" && it.category == "Reports") }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Tab Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    "COGNITIVE TEMPLATES",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = ElegantText,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    "Deploy industry-grade workflows instantly.",
                    style = MaterialTheme.typography.bodySmall.copy(color = ElegantSubtext)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Horizontal Category Select Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categories.forEach { cat ->
                val isSelected = selectedCategory == cat
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) PurpleAccentLight else ElegantSurface)
                        .border(1.dp, if (isSelected) PurpleAccentLight else ElegantBorder, RoundedCornerShape(20.dp))
                        .clickable { selectedCategory = cat }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = cat,
                        color = if (isSelected) PurpleAccentHeavy else ElegantText,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (showDeploySuccessMessage != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SuccessGreen.copy(alpha = 0.15f))
                    .border(1.dp, SuccessGreen, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = showDeploySuccessMessage!!,
                        color = ElegantText,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.weight(1.0f)
                    )
                    IconButton(onClick = { showDeploySuccessMessage = null }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = ElegantText)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Templates List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.weight(1.0f)
        ) {
            items(filteredTemplates, key = { it.id }) { template ->
                TemplateCard(
                    template = template,
                    onCustomize = { selectedTemplateForDeployment = template }
                )
            }
        }
    }

    if (selectedTemplateForDeployment != null) {
        CustomiseTemplateDeploymentDialog(
            template = selectedTemplateForDeployment!!,
            clients = clients,
            onDismiss = { selectedTemplateForDeployment = null },
            onDeploy = { clientId, clientName, name, desc, trigger, steps ->
                onDeployWorkflow(clientId, clientName, name, desc, trigger, steps)
                onPostLog(
                    0, 
                    name, 
                    "Successfully deployed template: $name as workflow for client: $clientName", 
                    "SUCCESS"
                )
                showDeploySuccessMessage = "Workflow pipeline '$name' successfully deployed to client $clientName!"
                selectedTemplateForDeployment = null
            }
        )
    }
}

@Composable
fun TemplateCard(
    template: WorkflowTemplate,
    onCustomize: () -> Unit
) {
    val badgeBg = when (template.category) {
        "Data Entry" -> SuccessGreen.copy(alpha = 0.15f)
        "Customer Support" -> PurpleAccentLight.copy(alpha = 0.15f)
        "Social Media" -> WarningOrange.copy(alpha = 0.15f)
        else -> Color(0xFF0D9488).copy(alpha = 0.15f)
    }
    
    val badgeTextColor = when (template.category) {
        "Data Entry" -> SuccessGreen
        "Customer Support" -> PurpleAccentLight
        "Social Media" -> WarningOrange
        else -> Color(0xFF22D3EE)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, ElegantBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = ElegantSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(30.dp))
                        .background(badgeBg)
                        .padding(horizontal = 10.dp, vertical = 2.dp)
                ) {
                    Text(
                        template.category.uppercase(),
                        color = badgeTextColor,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 9.sp)
                    )
                }
                
                Text(
                    "Odoo 10x Speed",
                    style = MaterialTheme.typography.labelSmall.copy(color = SuccessGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = template.name,
                style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = template.description,
                style = MaterialTheme.typography.bodySmall.copy(color = ElegantSubtext, lineHeight = 16.sp)
            )

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = ElegantBorder)
            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Build, contentDescription = null, tint = PurpleAccentLight, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    "Steps: " + template.defaultSteps.split(",").joinToString(" → ") { it.replace("Action:", "").replace("Trigger:", "") },
                    style = MaterialTheme.typography.labelSmall.copy(color = PurpleAccentLight, fontWeight = FontWeight.Bold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1.0f)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    template.insights,
                    style = MaterialTheme.typography.labelSmall.copy(color = SuccessGreen),
                    modifier = Modifier.weight(1.0f)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onCustomize,
                colors = ButtonDefaults.buttonColors(containerColor = PurpleAccentLight, contentColor = PurpleAccentHeavy),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Customize & Deploy Template", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomiseTemplateDeploymentDialog(
    template: WorkflowTemplate,
    clients: List<Client>,
    onDismiss: () -> Unit,
    onDeploy: (Int, String, String, String, String, String) -> Unit
) {
    var selectedClientIndex by remember { mutableStateOf(0) }
    var pipelineName by remember { mutableStateOf(template.name) }
    var description by remember { mutableStateOf(template.description) }
    var triggerType by remember { mutableStateOf(template.defaultTrigger) }
    var steps by remember { mutableStateOf(template.defaultSteps) }
    
    var errorMsg by remember { mutableStateOf<String?>(null) }
    
    val triggerOptions = listOf("Webhook", "Email Received", "Schedule", "Form Saved")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("CUSTOMIZE BLUEPRINT DEPLOYMENT", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("Base Template: ${template.name}", style = MaterialTheme.typography.labelSmall.copy(color = PurpleAccentLight))
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("Select Target Workspace Client", style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext))
                    if (clients.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Black.copy(alpha = 0.2f))
                                .border(1.dp, ElegantBorder, RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "No onboarded clients. Add a client in the Clients tab first to deploy this pipeline.",
                                style = MaterialTheme.typography.bodySmall.copy(color = ErrorRed),
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        var expandedDropdown by remember { mutableStateOf(false) }
                        val currentClient = clients.getOrNull(selectedClientIndex)
                        
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(ElegantSurface)
                                .border(1.dp, ElegantBorder, RoundedCornerShape(8.dp))
                                .clickable { expandedDropdown = true }
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    currentClient?.company ?: "Select Client",
                                    color = Color.White,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = PurpleAccentLight)
                            }
                            
                            DropdownMenu(
                                expanded = expandedDropdown,
                                onDismissRequest = { expandedDropdown = false },
                                modifier = Modifier
                                    .fillMaxWidth(0.8f)
                                    .background(ElegantSurface)
                            ) {
                                clients.forEachIndexed { index, client ->
                                    DropdownMenuItem(
                                        text = { Text(client.company, color = Color.White) },
                                        onClick = {
                                            selectedClientIndex = index
                                            expandedDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = pipelineName,
                        onValueChange = { pipelineName = it },
                        label = { Text("Pipeline Display Name") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            unfocusedBorderColor = ElegantBorder,
                            focusedBorderColor = PurpleAccentLight,
                            cursorColor = PurpleAccentLight
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Task Description") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            unfocusedBorderColor = ElegantBorder,
                            focusedBorderColor = PurpleAccentLight,
                            cursorColor = PurpleAccentLight
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }

                item {
                    Text("Trigger Activation State", style = MaterialTheme.typography.labelSmall.copy(color = ElegantSubtext))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        triggerOptions.forEach { t ->
                            val isSelected = triggerType == t
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSelected) PurpleAccentLight else Color.Transparent)
                                    .border(1.dp, if (isSelected) PurpleAccentLight else ElegantBorder, RoundedCornerShape(4.dp))
                                    .clickable { triggerType = t }
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = t,
                                    color = if (isSelected) PurpleAccentHeavy else ElegantSubtext,
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = steps,
                        onValueChange = { steps = it },
                        label = { Text("Node Link Block Steps (comma separated)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            unfocusedBorderColor = ElegantBorder,
                            focusedBorderColor = PurpleAccentLight,
                            cursorColor = PurpleAccentLight
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("e.g. Trigger, Action:1, Action:2") }
                    )
                }

                if (errorMsg != null) {
                    item {
                        Text(text = errorMsg!!, color = ErrorRed, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val client = clients.getOrNull(selectedClientIndex)
                    if (client == null) {
                        errorMsg = "Onboard a client first."
                    } else if (pipelineName.isEmpty() || description.isEmpty() || steps.isEmpty()) {
                        errorMsg = "Required parameter fields are empty."
                    } else {
                        onDeploy(client.id, client.company, pipelineName, description, triggerType, steps)
                    }
                },
                enabled = clients.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = PurpleAccentLight, contentColor = PurpleAccentHeavy)
            ) {
                Text("Deploy to workspace", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color.White)
            }
        },
        containerColor = ElegantSurface
    )
}
