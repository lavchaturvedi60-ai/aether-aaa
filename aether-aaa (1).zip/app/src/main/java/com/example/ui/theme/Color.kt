package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Dark Palette Colors based on the Design HTML
val ElegantBg = Color(0xFF1C1B1F)        // #1C1B1F
val ElegantText = Color(0xFFE6E1E5)      // #E6E1E5
val ElegantSubtext = Color(0xFFCAC4D0)   // #CAC4D0
val ElegantSurface = Color(0xFF2B2930)   // #2B2930 (Card Backgrounds)
val ElegantBorder = Color(0xFF49454F)    // #49454F (Card Borders/Outlines)
val ElegantNavBg = Color(0xFF211F26)     // #211F26

// Accent & Highlight Purples
val PurpleAccentLight = Color(0xFFD0BCFF)   // #D0BCFF (M3 Purple Light Accent for headers/icons)
val PurpleAccentHeavy = Color(0xFF381E72)   // #381E72 (Deep Purple)
val PurpleAccentMuted = Color(0xFF4F378B)   // #4F378B (Active bottom indicator)
val PurpleAccentText = Color(0xFF21005D)    // #21005D (Contrast dark purple text)
val PurpleAccentContainer = Color(0xFFEADDFF) // #EADDFF (Lavender highlighting)

val SuccessGreen = Color(0xFF00E676)
val WarningOrange = Color(0xFFFFAB40)
val ErrorRed = Color(0xFFFF5252)


