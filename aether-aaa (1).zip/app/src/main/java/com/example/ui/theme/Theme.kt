package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = PurpleAccentLight,
    secondary = PurpleAccentMuted,
    tertiary = PurpleAccentHeavy,
    background = ElegantBg,
    surface = ElegantSurface,
    onBackground = ElegantText,
    onSurface = ElegantText,
    error = ErrorRed,
    onPrimary = PurpleAccentText,
    onSecondary = ElegantText
)

private val LightColorScheme = lightColorScheme(
    primary = PurpleAccentHeavy,
    secondary = PurpleAccentMuted,
    tertiary = PurpleAccentLight,
    background = ElegantText,
    surface = Color(0xFFFFFFFF),
    onBackground = ElegantBg,
    onSurface = ElegantBg,
    error = ErrorRed,
    onPrimary = Color.White,
    onSecondary = Color.White
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is disabled by default to guarantee our Gorgeous handcrafted "Elegant Dark" styling is loaded everywhere!
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
