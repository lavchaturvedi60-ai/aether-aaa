package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AgencyDatabase
import com.example.data.local.entity.AgentLog
import com.example.data.local.entity.AutomationWorkflow
import com.example.data.local.entity.Client
import com.example.data.local.entity.Project
import com.example.data.local.entity.Task
import com.example.data.repository.AgencyRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

class AgencyViewModel(private val repository: AgencyRepository) : ViewModel() {

    // --- State Streams ---
    val clients: StateFlow<List<Client>> = repository.allClients
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val workflows: StateFlow<List<AutomationWorkflow>> = repository.allWorkflows
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val logs: StateFlow<List<AgentLog>> = repository.allLogs
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val projects: StateFlow<List<Project>> = repository.allProjects
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val tasks: StateFlow<List<Task>> = repository.allTasks
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // --- UI/Operation states ---
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _coPilotResponse = MutableStateFlow<String?>(null)
    val coPilotResponse: StateFlow<String?> = _coPilotResponse.asStateFlow()

    private val _isSimulating = MutableStateFlow<Int?>(null) // workflowId if simulating
    val isSimulating: StateFlow<Int?> = _isSimulating.asStateFlow()

    // --- User Custom Settings ---
    private val _logTheme = MutableStateFlow("Obsidian")
    val logTheme: StateFlow<String> = _logTheme.asStateFlow()

    private val _adMode = MutableStateFlow("Free") // "Free" (Advertising model) or "Premium" (Ad-free)
    val adMode: StateFlow<String> = _adMode.asStateFlow()

    private val _customAgencyName = MutableStateFlow("Nexus AI Agency")
    val customAgencyName: StateFlow<String> = _customAgencyName.asStateFlow()

    private val _maxLogLimit = MutableStateFlow(100)
    val maxLogLimit: StateFlow<Int> = _maxLogLimit.asStateFlow()

    // --- Subscription Plan States ---
    private val _currentPlan = MutableStateFlow("Free") // "Free", "Silver", "Gold", "Max"
    val currentPlan: StateFlow<String> = _currentPlan.asStateFlow()

    private val _isBillingYearly = MutableStateFlow(false)
    val isBillingYearly: StateFlow<Boolean> = _isBillingYearly.asStateFlow()

    // --- High Fidelity Settings Options ---
    private val _cacheAnswers = MutableStateFlow(true)
    val cacheAnswers: StateFlow<Boolean> = _cacheAnswers.asStateFlow()

    private val _aiCreativity = MutableStateFlow(0.7f) // temperature simulation
    val aiCreativity: StateFlow<Float> = _aiCreativity.asStateFlow()

    private val _geminiModelSelected = MutableStateFlow("Gemini-3.5-flash")
    val geminiModelSelected: StateFlow<String> = _geminiModelSelected.asStateFlow()

    private val _realtimeLogsActive = MutableStateFlow(true)
    val realtimeLogsActive: StateFlow<Boolean> = _realtimeLogsActive.asStateFlow()

    // Fast local memory cache for rapid consultations
    private val fastAnswersCache = mapOf(
        "draft client sow contract proposal" to """
            # 📄 STATEMENT OF WORK (SOW) PROPOSAL
            **Assigned Agency**: Nexus AI Cognition
            **Client Target**: Enterprise Integration Lead
            
            ## 1. PROJECT OBJECTIVES
            Deploy Aether Cognitive Agent nodes to replace outdated Odoo ERP sync triggers. Streamline Webhook capture arrays and deliver diagnostic dashboards in under 300ms.
            
            ## 2. SCOPE OF SERVICES
            - Provision live custom endpoints for automated Stripe & Webhook event capture.
            - Compile and train client business process cognitive triggers.
            - Deliver automated pipeline diagnostic alerts with zero background infrastructure delay.
            
            ## 3. SLA & METRICS
            - API Execution Speed: <400ms average
            - Agent Availability Rate: 99.98%
            - Response Latency: Sub-second.
        """.trimIndent(),
        
        "explain how aether operates faster than odoo erp" to """
            # ⚡ COGNITIVE REPLACEMENT VS. LEGACY DATA BASES
            
            Aether OS completely displaces standard Odoo ERP frameworks by running **Cognitive Pipeline Arrays** in memory.
            
            ### Why it is 10x faster:
            1. **Zero Database Blockages**: Traditional Odoo workflows instantiate synchronous SQL blocking queues. Aether uses reactive event queues.
            2. **Built-in LLM Warm-Start**: Integrated Gemini-3.5-flash model pre-compilation bypasses standard translation layers.
            3. **Distributed Agent Nodes**: Orchestrates actions concurrently via client-side states, resolving dependencies in real-time.
        """.trimIndent(),
        
        "generate python make.com webhook trigger boilerplates" to """
            # 💻 FAST MAKE.COM WEBHOOK CONNECTOR
            ```python
            import requests
            import json
            import time

            WEBHOOK_URL = "https://hook.us1.make.com/aether-os-agent-node"

            def dispatch_cognitive_event(workflow_name, client, payload):
                envelope = {
                    "client": client,
                    "timestamp": int(time.time()),
                    "origin": "Aether OS VIP Console",
                    "payload": payload,
                    "event_id": f"evt_{int(time.time() * 1000)}"
                }
                headers = {"Content-Type": "application/json"}
                response = requests.post(WEBHOOK_URL, data=json.dumps(envelope), headers=headers)
                return response.status_code

            # Trigger immediate test run
            status = dispatch_cognitive_event("Make Trigger", "Nexus Client", {"friction_score": "Moderate"})
            print(f"Aether pipeline dispatch status: {status}")
            ```
        """.trimIndent(),
        
        "pitch ideas for high-ticket real estate automations" to """
            # 🏘️ HIGH-TICKET REAL ESTATE AUTOMATIONS
            
            Premium automated pipeline ideas generating over ${'$'}10,000 in monthly consultation fees:
            
            1. **Active MLS Lead Diagnostic & Enricher**
               Automatically scrapes incoming MLS registrations, feeds credentials into Aether's diagnostic engine to calculate buyer intent, and drafts a custom personalized greeting on WhatsApp.
               
            2. **Generative Lease Document Contract Builder**
               Triggers a webhook when a deposit is matched via Stripe. Automatically generates a formal localized lease contract and schedules auto-reminders for digital signatures.
        """.trimIndent()
    )

    fun setLogTheme(theme: String) {
        _logTheme.value = theme
    }

    fun setAdMode(mode: String) {
        _adMode.value = mode
    }

    fun setCustomAgencyName(name: String) {
        // Only VIP Tier ("Max") is authorized to rename the agency identity overlay!
        if (_currentPlan.value == "Max") {
            _customAgencyName.value = name
        } else {
            postLog(
                workflowId = 0,
                workflowName = "Brand Protector",
                message = "REJECTED: Upgraded subscription plan required to apply custom white-labeled agency branding.",
                type = "ERROR"
            )
        }
    }

    fun setMaxLogLimit(limit: Int) {
        // Enforce max log rules by plan
        val allowedMax = when (_currentPlan.value) {
            "Free" -> 50
            "Silver" -> 150
            "Gold" -> 500
            else -> 5000
        }
        val validatedValue = limit.coerceAtMost(allowedMax)
        _maxLogLimit.value = validatedValue
    }

    fun setSubscriptionPlan(plan: String, isYearly: Boolean) {
        _currentPlan.value = plan
        _isBillingYearly.value = isYearly
        
        // Dynamic side-effects
        if (plan == "Free") {
            _adMode.value = "Free"
            _maxLogLimit.value = 50
        } else {
            _adMode.value = "Premium"
            when (plan) {
                "Silver" -> _maxLogLimit.value = 150
                "Gold" -> _maxLogLimit.value = 500
                "Max" -> _maxLogLimit.value = 1000
            }
        }
        postLog(
            workflowId = 0,
            workflowName = "Billing Agent",
            message = "Subscription tier upgraded to [$plan - ${if (isYearly) "Yearly" else "Monthly"}] Active. Enjoy advanced node clearance.",
            type = "SUCCESS"
        )
    }

    fun setCacheAnswers(enabled: Boolean) {
        _cacheAnswers.value = enabled
    }

    fun setAiCreativity(value: Float) {
        _aiCreativity.value = value
    }

    fun setGeminiModel(model: String) {
        _geminiModelSelected.value = model
    }

    fun setRealtimeLogsActive(active: Boolean) {
        _realtimeLogsActive.value = active
    }

    init {
        // Pre-seed the experience
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
        }
    }

    // --- Client Operations ---
    fun addClient(name: String, company: String, email: String, monthlyRetainer: Double, businessAudit: String) {
        viewModelScope.launch {
            val limit = when (_currentPlan.value) {
                "Free" -> 2
                "Silver" -> 5
                "Gold" -> 15
                else -> 9999
            }
            if (clients.value.size >= limit) {
                postLog(
                    workflowId = 0,
                    workflowName = "Billing Agent",
                    message = "BLOCKED: Client Registration limit ($limit) reached for [_currentPlan.value] Tier. Upgrade in System Settings to unlock capacity.",
                    type = "ERROR"
                )
                return@launch
            }
            repository.insertClient(
                Client(
                    name = name,
                    company = company,
                    email = email,
                    stage = "Lead",
                    monthlyRetainer = monthlyRetainer,
                    businessAudit = businessAudit
                )
            )
        }
    }

    fun updateClientStage(client: Client, newStage: String) {
        viewModelScope.launch {
            repository.updateClient(client.copy(stage = newStage))
        }
    }

    fun deleteClient(client: Client) {
        viewModelScope.launch {
            repository.deleteClient(client)
        }
    }

    // --- Workflow Operations ---
    fun addWorkflow(clientId: Int, clientName: String, name: String, description: String, triggerType: String, steps: String) {
        viewModelScope.launch {
            val limit = when (_currentPlan.value) {
                "Free" -> 3
                "Silver" -> 6
                "Gold" -> 20
                else -> 9999
            }
            if (workflows.value.size >= limit) {
                postLog(
                    workflowId = 0,
                    workflowName = "Billing Agent",
                    message = "BLOCKED: Workflow designer capacity ($limit) reached for active subscription. Upgrade in Settings.",
                    type = "ERROR"
                )
                return@launch
            }
            repository.insertWorkflow(
                AutomationWorkflow(
                    clientId = clientId,
                    clientName = clientName,
                    name = name,
                    description = description,
                    steps = steps,
                    triggerType = triggerType,
                    status = "Draft",
                    apiCallsCount = 0,
                    successRate = 1.0f
                )
            )
        }
    }

    fun updateWorkflowStatus(workflow: AutomationWorkflow, status: String) {
        viewModelScope.launch {
            repository.updateWorkflow(workflow.copy(status = status))
        }
    }

    fun deleteWorkflow(workflow: AutomationWorkflow) {
        viewModelScope.launch {
            repository.deleteWorkflow(workflow)
        }
    }

    // --- Log Dispatcher ---
    fun postLog(workflowId: Int, workflowName: String, message: String, type: String) {
        viewModelScope.launch {
            try {
                val currentLogs = logs.value
                val limit = _maxLogLimit.value
                if (currentLogs.size >= limit) {
                    val trimCount = currentLogs.size - limit + 1
                    repository.trimOldestLogs(trimCount)
                }
            } catch (e: Exception) {
                // Ignore any database trim error
            }
            repository.insertAgentLog(
                AgentLog(
                    workflowId = workflowId,
                    workflowName = workflowName,
                    message = message,
                    type = type
                )
            )
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            repository.clearLogs()
        }
    }

    // --- Gemini Interactive Core ---
    fun diagnoseClient(client: Client) {
        viewModelScope.launch {
            _isGenerating.value = true
            _coPilotResponse.value = "Initiating Nexus client diagnostic protocols on ${client.company}..."
            
            val prompt = """
                You are Aether, the core AI consultant built into our agency software. 
                Perform a high-performance clinical operational diagnostic check for:
                Client: ${client.name}
                Company: ${client.company}
                Stated Process Bottleneck: ${client.businessAudit}
                
                Provide:
                1. A brief diagnostic score (High Friction, Moderate Sync Leak, or Dead Process).
                2. Explicit blueprint solution incorporating multi-step integrations with Gemini or Webhooks (specifically design-engineered to replace Odoo features, working 10x faster).
                3. High-level custom prompt guideline for their automation agent.
                
                Keep formatting extremely clean, aesthetic, and professional in markdown.
            """.trimIndent()
            
            val result = repository.callGemini(prompt, "You are a professional AI Automation Agency Lead Consultant.")
            _coPilotResponse.value = result
            _isGenerating.value = false
            
            // Post log about diagnostic accomplishment
            postLog(
                workflowId = 0,
                workflowName = "Co-pilot Consultant",
                message = "Executed automated diagnostic audit for client: ${client.company}. Blueprint mapped.",
                type = "SUCCESS"
            )
        }
    }

    fun generateWorkflowFromText(description: String, clientName: String? = null) {
        viewModelScope.launch {
            _isGenerating.value = true
            _coPilotResponse.value = "Architecting custom Odoo-style step integration..."
            
            // Artificial latency curve depending on active purchased plan
            val delayMs = when (_currentPlan.value) {
                "Free" -> 3000L
                "Silver" -> 1500L
                "Gold" -> 500L
                else -> 50L // VIP is blazingly instant
            }
            delay(delayMs)

            val prompt = """
                Formulate an automated multi-step blueprint from this prompt: "$description"
                ${if (clientName != null) "Assigned Client: $clientName" else ""}
                
                Please structure your response with:
                1. ## 🔗 FLOW PIPELINE: A numbered list of exact visual node actions (e.g., [TRIGGER] Webhook -> [ACTION] Classifier -> [ACTION] CRM Database write). Keep nodes concise.
                2. ## 🤖 SYSTEM INSIGHTS: How Gemini-3.5-flash will optimize this task, details on latency reduction, and how custom prompts replace Odoo ERP overhead.
                3. ## 💻 SAMPLE WEBHOOK CODE: A robust, functional python or node.js snippet doing the dispatch action.
            """.trimIndent()

            val result = repository.callGemini(prompt, "You are an Elite Solutions Architect specialized in AI Automation pipelines.")
            _coPilotResponse.value = result
            _isGenerating.value = false
        }
    }

    fun askCoPilot(question: String) {
        viewModelScope.launch {
            _isGenerating.value = true
            _coPilotResponse.value = "Querying Aether OS Intelligence..."
            
            // Determine active speed latency curve depending on plan purchased
            val activeTier = _currentPlan.value
            val isCacheEnabled = _cacheAnswers.value
            
            val normalizedQuery = question.trim().lowercase()
            val cachedResult = if (isCacheEnabled) fastAnswersCache[normalizedQuery] else null

            if (cachedResult != null) {
                // Pre-cached immediate cognitive answer
                val delayMs = when (activeTier) {
                    "Free" -> 1000L
                    "Silver" -> 500L
                    "Gold" -> 150L
                    else -> 0L // VIP is immediate
                }
                if (delayMs > 0) delay(delayMs)
                _coPilotResponse.value = cachedResult
            } else {
                // Live fetch
                val delayMs = when (activeTier) {
                    "Free" -> 4000L
                    "Silver" -> 2000L
                    "Gold" -> 800L
                    else -> 100L // VIP is ultra optimized
                }
                delay(delayMs)
                val result = repository.callGemini(question, "You are Aether OS, the ultimate high-speed enterprise terminal manager representing Odoo's next-generation cognitive replacement.")
                _coPilotResponse.value = result
            }
            _isGenerating.value = false
        }
    }

    fun resetCoPilotResponse() {
        _coPilotResponse.value = null
    }

    // --- Active Workflow Run Simulator ---
    fun simulateWorkflowRun(workflow: AutomationWorkflow) {
        if (_isSimulating.value == workflow.id) return
        
        viewModelScope.launch {
            _isSimulating.value = workflow.id
            postLog(
                workflowId = workflow.id,
                workflowName = workflow.name,
                message = "[SIMULATION INITIATED]: Setting up temporary sandbox nodes...",
                type = "INFO"
            )
            delay(1200)

            // Step 1: Trigger run
            postLog(
                workflowId = workflow.id,
                workflowName = workflow.name,
                message = "Active Trigger activated: [${workflow.triggerType}] received incoming byte stream.",
                type = "INFO"
            )
            delay(1400)

            // Step 2: Agent execution
            val parts = workflow.steps.split(",")
            val stepToLog = parts.find { it.contains("Gemini") || it.contains("AI") || it.contains("Classifier") }
                ?: parts.getOrNull(2) ?: "AI Handler Model"
            
            postLog(
                workflowId = workflow.id,
                workflowName = workflow.name,
                message = "Executing node content: `$stepToLog` analyzing structure contents.",
                type = "INFO"
            )
            delay(1500)

            // Step 3: Success or minor failure check
            val isSuccess = Random.nextFloat() > 0.15f // 85% success chance
            val latency = Random.nextInt(180, 520)
            
            if (isSuccess) {
                val newCount = workflow.apiCallsCount + 1
                // Recalculate success rate slightly
                val currentFails = (workflow.apiCallsCount * (1.0f - workflow.successRate)).toInt()
                val newRate = (newCount - currentFails).toFloat() / newCount.toFloat()

                repository.updateWorkflow(
                    workflow.copy(
                        apiCallsCount = newCount,
                        successRate = newRate,
                        lastExecutedAt = System.currentTimeMillis()
                    )
                )

                postLog(
                    workflowId = workflow.id,
                    workflowName = workflow.name,
                    message = "SUCCESS: Deployed automation pipeline executed perfectly. Runtime latency: ${latency}ms.",
                    type = "SUCCESS"
                )
            } else {
                val newCount = workflow.apiCallsCount + 1
                val currentFails = (workflow.apiCallsCount * (1.0f - workflow.successRate)).toInt() + 1
                val newRate = (newCount - currentFails).toFloat() / newCount.toFloat()

                repository.updateWorkflow(
                    workflow.copy(
                        apiCallsCount = newCount,
                        successRate = newRate,
                        lastExecutedAt = System.currentTimeMillis()
                    )
                )

                postLog(
                    workflowId = workflow.id,
                    workflowName = workflow.name,
                    message = "ERROR: Failed to update destination node (FHIR endpoint timed out). Automated retries initiated.",
                    type = "ERROR"
                )
            }

            _isSimulating.value = null
        }
    }

    // --- Project Operations ---
    fun addProject(clientId: Int, clientName: String, name: String, description: String, deadline: Long, status: String) {
        viewModelScope.launch {
            repository.insertProject(
                Project(
                    clientId = clientId,
                    clientName = clientName,
                    name = name,
                    description = description,
                    deadline = deadline,
                    status = status
                )
            )
        }
    }

    fun updateProject(project: Project) {
        viewModelScope.launch {
            repository.updateProject(project)
        }
    }

    fun deleteProject(project: Project) {
        viewModelScope.launch {
            repository.deleteProject(project)
        }
    }

    // --- Task Operations ---
    fun addTask(projectId: Int, title: String, description: String, assignee: String, deadline: Long, stage: String = "Todo") {
        viewModelScope.launch {
            repository.insertTask(
                Task(
                    projectId = projectId,
                    title = title,
                    description = description,
                    assignee = assignee,
                    deadline = deadline,
                    isCompleted = (stage == "Completed"),
                    stage = stage
                )
            )
        }
    }

    fun updateTask(task: Task) {
        viewModelScope.launch {
            repository.updateTask(task)
        }
    }

    fun updateTaskStage(task: Task, newStage: String) {
        viewModelScope.launch {
            repository.updateTask(
                task.copy(
                    stage = newStage,
                    isCompleted = (newStage == "Completed")
                )
            )
        }
    }

    fun deleteTask(task: Task) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }

    // Simple Factory pattern for clean Compose injects
    companion object {
        val Factory: ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>, extras: androidx.lifecycle.viewmodel.CreationExtras): T {
                // Get application class from context
                val application = extras[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as Application
                val database = AgencyDatabase.getDatabase(application)
                val repository = AgencyRepository(database.agencyDao())
                return AgencyViewModel(repository) as T
            }
        }
    }
}
